from django.shortcuts import render,redirect

# Create your views here.

from django.views.generic import CreateView,ListView,CreateView,DetailView,ListView,DetailView,View

from master.models import FeedbackModel
from master.forms import FeedbackForm

from master.models import CategoryModel
from master.forms import CategoryForm

from master.models import BookCategoryModel
from master.forms import BookCategoryForm




class CreateFeedbackView(CreateView):
	template_name='create_feedback.html'
	model=FeedbackModel
	form_class=FeedbackForm
	success_url='/gen/home/'

class ListFeedbackView(ListView):	
	template_name = 'list_feedbacks.html'
	model = FeedbackModel
	context_object_name = 'feedbacks'


class CategoryView(CreateView):
	template_name='category.html'
	model=CategoryModel
	form_class=CategoryForm
	success_url='/gen/home/'

class FeedbackDetailView(DetailView):
	template_name = 'feedback_details.html'
	model = FeedbackModel	

class ListCategoryView(ListView): 
	template_name = 'list_category.html'
	model = CategoryModel
	context_object_name = 'category'
	

class CategoryDetailView(DetailView):
	template_name = 'category_details.html'
	model = CategoryModel

class NewBookCategoryView(View):
	template_name = 'new_book_category.html'
	form_class = BookCategoryForm

	def get(self,request):
		form = self.form_class()
		context = {
		'cat_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			book_cat = BookCategoryModel.objects.create(
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				cat_code = request.POST.get('cat_code')
				)
			return redirect('/gen/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


