from django.shortcuts import render,redirect
# Create your views here.
from django.views.generic import TemplateView,View

from general.models import ContactModel,FeedCategoryModel

from general.forms import ContactForm,FeedCategoryForm



class HomeView(TemplateView):
	template_name='home.html'


class AboutView(TemplateView):
	template_name = 'about.html'

class ContactView(View):
	template_name = 'contact_us.html'
	model = ContactModel
	form_class = ContactForm


	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)
	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactModel.objects.create(
				name =request.POST.get('name'),
				place = request.POST.get('place'),
				contact = request.POST.get('contact'),
				email = request.POST.get('email')
				)

			return redirect('/general/home')
		else:
		    form = self.form_class()
		    return render(request,self.template_name,{'form':form})





class IndexView(TemplateView):
	template_name = 'index.html'
	model = ContactModel
	form_class = ContactForm



class FeedCategoryView(View):
    template_name = 'feed_catgry.html'
    form_class = FeedCategoryForm

    def get(self,request):
        form = self.form_class()
        context ={
        'contact_form':form
        }
        return render(request,self.template_name,context)

    def post(self,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            book_cat = FeedCategoryModel.objects.create(
                name = request.POST.get('name'),
                category = request.POST.get('category'),
                rate = request.POST.get('rate'),
                description = request.POST.get('description'),
                status = request.POST.get('status'),
                created_on = request.POST.get('created_on')
                )
            return redirect('/general/home/')
        else:
            form = self.form_class()
            return render(request,self.template_name,{'form':form})   




	