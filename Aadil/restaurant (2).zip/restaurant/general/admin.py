from django.contrib import admin

# Register your models here.
from general.models import ContactModel,FeedCategoryModel

admin.site.register(ContactModel)

admin.site.register(FeedCategoryModel)

