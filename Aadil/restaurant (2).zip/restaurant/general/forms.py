from django import forms

from general.models import ContactModel,FeedCategoryModel

class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','email','place','contact']


class FeedCategoryForm(forms.ModelForm):
	class Meta:
		model = FeedCategoryModel
		# fields = ['name','category','rate','description']
		exclude = ('status','created_on')