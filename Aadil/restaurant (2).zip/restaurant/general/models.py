from django.db import models

# Create your models here.
class ContactModel(models.Model):
	name = models.CharField(max_length=15)
	email= models.EmailField()
	place= models.CharField(max_length=20)
	contact= models.CharField(max_length=15)

	def __str__(self):
		return self.name



class FeedCategoryModel(models.Model):
	name = models.CharField(max_length=20)
	category = models.CharField(max_length=15)
	rate = models.IntegerField()
	description = models.TextField(max_length=50)
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)


	def __str__(self):
		return self.name
	



