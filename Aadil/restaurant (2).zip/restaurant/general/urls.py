from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from general.views import HomeView,AboutView,ContactView,IndexView,FeedCategoryView



urlpatterns = [
    path(r'home/', HomeView.as_view() , name='home_page'),
    path(r'about/', AboutView.as_view() , name='home_page'),
    path(r'contact/', ContactView.as_view() , name='contact_page'),
    path(r'index/', IndexView.as_view() , name='index_page'),
    path(r'feedcategory/', FeedCategoryView.as_view() , name='feed_catgry_page')




]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)