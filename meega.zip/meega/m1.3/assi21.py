d={"dog":"willie","cat":"tom","mouse":"jerry"}
for key,value in d.items():
	print(value,"is a ",key)
