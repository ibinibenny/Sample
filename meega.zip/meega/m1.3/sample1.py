#newdict={num:num*num for num in [1,2,3,5,6]}
#print(newdict)

#dict1={1:"sun",2:"tree",3:"moon"}
#newdict1={k:v for k,v in dict1.items()}
#print(newdict1)
numbers=range(0,20)
newdic={n:n**2 for n in numbers if n%2 == 0}
print(newdic)


