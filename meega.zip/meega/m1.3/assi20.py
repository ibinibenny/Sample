dict1=dict()
sum=0
lm1=int(input('Enter the 1st Dic limit '))
for i in range(0,lm1):
	key=int(input('Enter Dic Key '))
	value=int(input('Enter Dic value '))
	dict1[key]=value
	sum=sum+(key+value)
print(dict1)
print('Sum is ',sum)
