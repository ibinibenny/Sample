lm=int(input('Enter the limit '))
def square():
	dict1=dict()
	for i in range(1,lm+1):
		key=i
		value=i*i
		dict1[key]=value
	return dict1
sq=square()
print(sq)





#python script
#n=int(input("Input a number "))
#d = dict()
#for x in range(1,n+1):
#    d[x]=x*x

#print(d) 


