dict1=dict()
dict2=dict()
lm1=int(input('Enter the 1st Dic limit '))
lm2=int(input('Enter the 2nd Dic limit '))
for i in range(0,lm1):
	key=input('Enter 1st Dic Key ')
	value=input('Enter 1st Dic value ')
	dict1[key]=value
print(dict1)
for j in range(0,lm2):
	key=input('Enter 2nd Dic Key ')
	value=input('Enter 2nd Dic value ')
	dict2[key]=value
print(dict2)
dict2.update(dict1)
print(dict2)
