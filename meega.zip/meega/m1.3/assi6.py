List = []
Number = int(input("enter the total number of list elements : "))
for i in range(1, Number + 1):
    value = int(input("enter the %d number: "%i))
    List.append(value)
total = sum(List)
print("\n Sum is : ", total)
