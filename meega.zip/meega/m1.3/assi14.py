list1,list2=[],[]
a,c=0,0
b,d=5,30
for i in range(1,b+1):
	a=i*i
	list1.append(a)
print('First 5 Digit=',list1)
for i in range(26,d+1):
	c=i*i
	list2.append(c)
print('Last 5 Digit=',list2)

