name=input('Enter the sentence')
def num():
	a=b=c=d=0
	dict1=dict()
	for i in range(len(name)):
		if (name[i].isalpha()):
			a=a+1
		elif (name[i].isdigit()):
			b=b+1
		else:
			c=0
	dict1[a]=b  #a key should be letter count and b value should be letter count 
	return dict1
d=num()
print(d)
