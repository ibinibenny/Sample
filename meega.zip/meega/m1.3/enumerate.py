my_list = ['apple', 'banana', 'grapes', 'pear']
for i in enumerate(my_list, 50):
    print(i)

