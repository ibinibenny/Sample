squares=[i*i for i in range(4,31)]
print(squares)
