l1=[]
l2=[]
l3=[]
a,b=1,2
lm1=int(input('Enter 1st limit '))
print('Enter 1st limit elements \t')
for i in range(lm1):
	n1=int(input(''))
	l1.append(n1)
print(l1)
#lm2=int(input('Enter 1st limit '))
print('Enter 2nd limit elements \t')
for j in range(lm1):
	n2=int(input(''))
	l2.append(n2)
print(l2)
#len=max(lm1,lm2)
#print(len)

for (k,j) in zip(l1,l2):
	print(k,j)	
	
