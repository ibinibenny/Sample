dict1=dict()
dict2=dict()
s=[]
a=[]
c=0
lm=int(input('Enter the limit '))
def mark():
	for i in range(0,lm):
		key=input('Enter Subject: ')
		value=int(input('Enter Mark: '))
		dict1[key]=value
	s=dict1
	dict2={k:v for (k,v) in dict1.items() if (v)>50}
	return dict2
c=mark()
print("subject having morethan 50 marks is ", c)	
