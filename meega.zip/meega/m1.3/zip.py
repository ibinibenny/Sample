a = (1,2,3)
b = ("John", "Charles", "Mike")
x = tuple(zip(a, b)) #zipping
print(x)
a,b=zip(*x)  #unzipping
print(a,b)

