list=[]
x=0
w=int(input("Enter the no: of words "))
print("enter the words")
while x<w:
	name=input('\t')
	list=list+[name.upper()]
	x=x+1
print(list)
