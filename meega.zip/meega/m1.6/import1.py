#import calendar  
#import datetime    
import time
#yy = 2017
#mm = 11 
#print(calendar.month(yy, mm))  



#print ("The calender of year 2018 is : ")  
#print (calendar.calendar(2018, 2, 1, 6))


#print(calendar.isleap(2016)) 


#yy=int(input("enter year: "))
#mm=int(input("enter month: "))
#print(calendar.month(yy,mm))


#datenow=datetime.date.today()
#print(datenow)

#ticks = time.time()
#print ("Number of ticks since 12:00am, January 1, 1970:", ticks)

localtime = time.asctime( time.localtime(time.time()) )
print ("Local current time :", localtime)

t=time.localtime(time.time())
print(time.strftime("%Y/%m/%d/%X",t))

