import random

#print(random.randrange(3, 9)) 


#print(random.randint(3, 9)) 

mylist = ["apple", "banana", "cherry"]
random.shuffle(mylist)

print(mylist) 
