import math
 
val = math.log(4)
print(val)
