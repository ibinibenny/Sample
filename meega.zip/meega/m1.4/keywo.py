def student(firstname, lastname):  
     print(firstname, lastname)                    
student(firstname ='meega', lastname ='jacob')     
student(lastname ='jacob', firstname ='meega')   
