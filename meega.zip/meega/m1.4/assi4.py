def power():
	a=[]
	lm=int(input('nter the limit:'))
	print('Enter the number:')
	for i in range(lm):
		num=int(input(''))
		a.append(num)
	n=list(map(lambda x:2**x,a))
	return n
z=power()
print(z)
