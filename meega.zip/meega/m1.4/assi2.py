def printDict():
	d=dict()
	for i in range(1,21):
		d[i]=i**2
	print(d)
		
printDict()

# using comprehension:
def printDict():
    dict={i:i**2 for i in range(1,21)}   # Using comprehension method and
    print(dict)

printDict()
