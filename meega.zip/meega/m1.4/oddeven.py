def evenOdd( x ): 
    if (x % 2 == 0): 
        print "even"
    else: 
        print "odd"
evenOdd(2) 
evenOdd(3) 
