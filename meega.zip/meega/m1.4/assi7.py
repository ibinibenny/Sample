dict1=dict()
def new_dic(l1,l2):
	for k in range(len(l1)):
		dict1[l1[k]]=l2[k]
	print(dict1)
l1=list()
l2=list()
lm=int(input('Enter the limit:'))
print('Enter 1st list number:')
for i in range(lm):
	num1=int(input(''))
	l1.append(num1)
l1.sort()
print('1st List:',l1)
#lm=int(input('Enter the limit:'))
print('Enter 2nd list Numbers:')
for j in range(lm):
	num2=int(input(''))
	l2.append(num2)
l2.sort()
print('2nd List:',l2)
new_dic(l1,l2)
