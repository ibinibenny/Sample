n=0
a=list()
def hai():
	n=int(input('Enter the limit: '))
	for i in range(0,n):
		if i%2==0:
			a.append(i)
	yield a
	
x=hai()
print(x.__next__())
