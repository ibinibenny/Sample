def vowel():
	list1=[]
	name=input('Enter the string:')
	vow=('a','e','i','o','u')
	list1=[name[i] 
	for i in range(len(name)) 
		if name[i] not in vow]
	return list1
z=vowel()
print(z)
