def add(x,y,z):
    print("sum:",x+y+z)

add(10,12,13)
