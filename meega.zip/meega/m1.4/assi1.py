num=int(input("Enter number"))
def odd():
	if(num%2==0):
		print("Number is even")
	else:
		print("Number is odd")
	return num
f=odd()
