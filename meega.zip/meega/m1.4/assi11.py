n=0
a=list()
b=list()
def div():
	n=int(input('Enter the limit: '))
	for i in range(0,n):
		if i%5==0 and i%7==0:
			a.append(i)
	yield a	
	
x=div()
print(x.__next__())
