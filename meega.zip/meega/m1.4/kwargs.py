#def myFun(**kwargs):  
#        d={}
#        for key,value in kwargs.items(): 
#                d[key]=value
#        print(d)
#myFun(first ='Geeks', mid ='for', last='Geeks') 



def add(*num):
    sum = 0
    
    for n in num:
        sum = sum + n

    print("Sum:",sum)

add(3,5)

