def myFun(x, y=50): 
    print("x: ", x) 
    print("y: ", y) 
myFun(10) 
