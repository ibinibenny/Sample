#A = [12,78,96,45,32]
#for i in range(len(A)):
#    min_= i
#    for j in range(i+1, len(A)):
#        if A[min_] > A[j]:
#            min_ = j
#    #swap
#    A[i], A[min_] = A[min_], A[i]
## main
#for i in range(len(A)):
#    print(A[i])


def selection_sort(sort_list):
    for i in range(len(sort_list)):
        smallest_element = min(sort_list[i:])
        index_of_smallest = sort_list.index(smallest_element)
        sort_list[i], sort_list[index_of_smallest] = sort_list[index_of_smallest], sort_list[i]
        print('\nPASS :', i + 1, sort_list)
    print ('\n\nThe sorted list: \t', sort_list)
 
 
 
lst = []
size = int(input("\nEnter size of the list: \t"))
 
for i in range(size):
    elements = int(input("Enter the element: \t"))
    lst.append(elements)
 
selection_sort(lst)
