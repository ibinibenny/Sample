#a=int(input("enter the first number: ")
#b=int(input("enter the second number: ")
def add_num(a,b):
	c=a+b
	return c
num1=5
num2=5
print("The sum is",add_num(num1,num2))
