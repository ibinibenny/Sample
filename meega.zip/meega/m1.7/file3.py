# Open a file
fo = open("fooo.txt", "r+")
print ("Name of the file: ", fo.name)

line = fo.readline()
print( "Read Line: %s" % (line))

# Get the current position of the file.
pos = fo.tell()
print ("Current Position: %d" % (pos))

# Close opend file
fo.close()
