d={5:"radix",8:"King",7:"yell"}
import json
data=json.dumps(d)
print(type(data))
with open("s.json","w") as f:
    a=f.write(data)
with open("s.json","r") as f:
    data=f.read()
    d=json.loads(data)
    print(type(d))
    print(d)


