a=input("Enter :")
def convert(a):
	try:
		print(int(a))
	except ValueError:
		print("Value is not integer")
	else:
		print("Value is integer")
	finally:
		print("Integers are all acceptable")
f=convert(a)
