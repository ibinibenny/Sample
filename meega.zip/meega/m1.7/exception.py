a=int(input("Enter 1stno:"))
b=int(input("enter 2ndno:"))
def addy(a,b):
	try:
		c=a+b
		print(c)
	except ValueError:
		print("Value does not add")
f=addy(a,b) 
