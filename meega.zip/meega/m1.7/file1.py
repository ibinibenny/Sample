f_obj = open("sample.txt","r")

for line in f_obj:
    print (line)

f_obj.close()
