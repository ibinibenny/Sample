a=4
if (a<5):
	try:
		raise Exception("No: is not operatable")
	except ValueError:
		print("No: is operable")
	else:
		print("Error")
