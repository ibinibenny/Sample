import csv
fp=csv.reader(open("file.csv","r"))
for i in fp:
	print(i)
