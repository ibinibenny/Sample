a=input("Enter :")
def convert(a):
	try:
		print(int(a))
	except ValueError:
		print("Value is not integer")
f=convert(a)
