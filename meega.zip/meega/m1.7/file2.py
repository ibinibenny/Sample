f = open("demofile.txt", "r")

print(f.seek(4))

