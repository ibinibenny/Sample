import csv
cp=csv.writer(open('file.csv','w'))
cp.writerows([('name','age','place'),('low','2','tolin'),('habbit','22','rasp')])
