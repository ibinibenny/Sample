a=4
if (a<5):
	raise Exception("No: is not operatable")
