from _thread import start_new_thread
def addy(a,b):
	c=a+b
	print(c)
def suby(a,b):
	c=a-b
	print(c)
t1=start_new_thread(addy,(70,80))
t2=start_new_thread(suby,(80,36))
a=input()

