class Employee:
 
    company = 'spectrum'
 
    @classmethod
    def message(cls):
        print('The Message is From %s Class' %cls.__name__)
        print('The Company Name is %s' %cls.company)
 
Employee.message()
