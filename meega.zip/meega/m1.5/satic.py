class Mathematics:
	@staticmethod
    def addNumbers(x,y):
        return x + y
# create addNumbers static method
#Mathematics.addNumbers=staticmethod(Mathematics.addNumbers)
Mathematics.addNumbers()
print('The sum is:', Mathematics.addNumbers(5, 10))
