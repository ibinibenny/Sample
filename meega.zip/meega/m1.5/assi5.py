class Shape:
	def area(self,l):
		area=0
		print("Shape's Area:",area)
class Square(Shape):
	def area(self,l):
		super().area(l) 
		area=l*l
		print("Square's Area:",area)		
l=int(input('Enter the Length: '))
s=Square()
s.area(l)
