class Employee:
      
    def add(self, a, b):
        print('The Sum of Two = ', a + b)
  
class Department(Employee):
  
    def add(self, a, b, c):
        print('The Sum of Three = ', a + b + c)
         
emp = Employee()
emp.add(10, 20)
  
print('------------')
dept = Department()
dept.add(50, 130, 90)
