class Bank_Account: 
    def __init__(self): 
        self.balance=0
        print("Welcome to the Deposit & Withdrawal of cash") 
  
    def deposit(self): 
        amount=int(input("Enter the amount to be Deposited: ")) 
        self.balance += amount 
        print(" Amount Deposited:",amount) 
  
    def withdraw(self): 
        amount = int(input("Enter amount to be Withdraw: ")) 
        if self.balance>=amount: 
            self.balance-=amount 
            print(" You Withdraw:", amount) 
        else: 
            print(" no balance  ") 
  
    def this(self): 
        print("available Balance=",self.balance) 
s = Bank_Account() 
s.deposit() 
s.withdraw() 
s.this() 
