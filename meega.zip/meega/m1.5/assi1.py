class A:
	def input(self):
		self.string=input('Enter a String: ')
		print(self.string)
	def upper(self):
		print(self.string.upper())

obj=A()
obj.input()
obj.upper()
