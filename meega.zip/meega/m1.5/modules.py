import assi3

assi3.Circle(7)
