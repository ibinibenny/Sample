class Circle:
	def __init__(self,r):
		self.r=radius
	def area(self):
		area=3.14*radius**2
		print('Area=',area)
radius=int(input('Enter the Radius: '))
a=Circle(radius)
a.area()
