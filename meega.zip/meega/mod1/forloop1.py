stre=("hellopy123thon4")
print("sring is:",stre)
x=len(stre)
alpahabets=0
digits=0
for i in range(x):
    if stre[i].isalpha():
        alpahabets=alpahabets+1
    if stre[i].isdigit():
        digits=digits+1
print("letters are",alpahabets)
print("numbers are",digits)



