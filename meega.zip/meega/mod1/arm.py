n1=int(input('Enter the number '))
n3,sum=0,0
n2,n3=n1,0
while n2>0:
	n=n2%10
	sum=sum+(n**3)
	n2//=10
if n1==sum:
	print('The number is Armstrong')
else:
	print('The number is not Armstrong')
