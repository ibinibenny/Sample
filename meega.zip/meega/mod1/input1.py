name=raw_input("enter your name")
print("name is",name)
num1=input("enter any number")
print("number is",num1)
num2=input("enter any number")
print("sum is",num1+num2)

