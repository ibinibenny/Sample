for i in range(8):
	if i == 5:
		break
	else:
		print(i)

