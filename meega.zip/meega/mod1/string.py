str1=input("enter first string")
str2=input("enter second string")
new=str1+" "+str2
print("strings to upper case",new.upper()) 
