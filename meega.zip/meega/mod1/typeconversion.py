x = 123
y = 3+4j

num = x * y

print("datatype of x:",type(x))
print("datatype of y:",type(y))

print("Value of num:",num)
print("datatype of num:",type(num))
