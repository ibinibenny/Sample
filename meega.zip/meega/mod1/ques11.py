i=1
s=0
for i in range(101,200):
	if i%7==0:
		print(i)
		s=s+i
print("sum of the integer numbers between 100 and 200 divisible by 7 are",s)


