num=int(input('Enter a Year= '))
if num%4==0:
	if num%100==0:
		if num%400==0:
			print('Given year is Leap year')
	else:
		print("not")
else:
	print('Given year is not a leap year')
	
