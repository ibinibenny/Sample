number=int(input("Enter any number: "))
if number%2==0:
    print("even number")
else:
    print("odd number")
print(number)
