for i in range(8):
	if i == 5:
		continue
	else:
		print(i)

