num1=1
num2=50
n1,n2,n3=0,0,0
for i in range(num1,num2+1):
	if i%2!=0:
		print(i)
		n1=i
		n2=n3
		n3=n1+n2
print('The sum is ',n3)
