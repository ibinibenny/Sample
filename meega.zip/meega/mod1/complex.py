n1=complex(input('Enter first number= '))
n2=complex(input('Enter second number= '))
add=n1+n2
print('Addition=',add)
sub=n1-n2
print('Subtraction=',sub)
mul=n1*n2
print('Multiplication=',mul)
div=n1/n2
print('Division=',div)
