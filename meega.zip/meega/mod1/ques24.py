i = 1
while i < 6:
  print(i)
  i =i + 1
