str3="return"

temp=str3[1:]

str4=temp.replace("r","$")
temp2=str3[0]
result=temp2+str4
print(result)
