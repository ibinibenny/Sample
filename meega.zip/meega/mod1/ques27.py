name=input('Enter the string of braces:')
def braces():
	a=b=0	
	for char in name:
		if char=='{':
			a=a+1
		else:
			b=b+1
	if a==b and name[0]=='{' and name[-1]=='}':
		f='TRUE'
	else:
		f='FALSE'
	return f
r=braces()
print(r) 

