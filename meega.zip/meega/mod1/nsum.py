n1=int(input('Enter a number '))
n2,n3=0,0
for i in range(1,n1+1):
	n1=i
	n2=n3
	n3=n1+n2
print('sum is ',n3)	
	
