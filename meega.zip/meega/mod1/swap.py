print("swapping two numbers")
num9 = input("num9 is :")
num10 = input("num10 is :")
temp = num9
num9 = num10
num10 = temp
print("Value of num9", num9)
print("Value of num10", num10)
