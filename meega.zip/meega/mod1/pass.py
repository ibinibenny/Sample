for i in range(8): 
   if i == 5:
      pass
      print (' pass  ')
   print(i)

