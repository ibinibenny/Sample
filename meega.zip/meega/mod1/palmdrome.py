name1=input('Enter a name ')
if (name1==name1[::-1]):
	print('The given name is palandrom')
else:
	print('The given name is not palandrom')
