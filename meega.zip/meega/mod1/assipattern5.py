n=2
for i in range(1,5):
	for j in range(1,i+1):
		print(n,end=' ')
		n=n+2
	print('\t')   
