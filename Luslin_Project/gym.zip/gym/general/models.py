from django.db import models

# Create your models here.
class ContactUsModel(models.Model):
	name = models.CharField(max_length=30)
	email = models.EmailField()
	phone_no = models.CharField(max_length=30,null=True,blank=True)
	message = models.TextField(max_length=500)
	

	def __str__(self):
		return self.name