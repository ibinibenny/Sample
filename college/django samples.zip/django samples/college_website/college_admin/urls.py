from django.conf.urls import url

from college_admin.views import CreateCourseView,CourseListView,CourseDetailView,AdminHomeView,LeaveTypeView,EditCourse
from faculty.views import HomeView


from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings

urlpatterns = [
	# url(r'home/',HomeView.as_view(),name='home'),
	url(r'^adminhome/$',AdminHomeView.as_view(),name='adminhome'),
 	url(r'^addcourse/$',CreateCourseView.as_view(),name = 'course'),
 	url(r'^courselist/$',CourseListView.as_view(),name = 'courselist'),
 	url(r'^coursedetail/(?P<pk>[0-9]+)/$',CourseDetailView.as_view(),name ='coursedetail'),
 	url(r'^addleave/$',LeaveTypeView.as_view(),name = 'leavetype'),
 	url(r'^editcourse/(?P<pk>[0-9]+)/$', EditCourse.as_view(), name='c_edit'),

 	]

urlpatterns+=static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
