# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from college_admin.forms import CreateCourseForm,leavetypeForm
from college_admin.models import CourseModel,leavetype
from django.views.generic import CreateView,TemplateView,ListView,DetailView,UpdateView


# Create your views here.

class AdminHomeView(TemplateView):
    template_name='admin_home.html'

class CreateCourseView(CreateView):
	template_name='add course.html'
	form_class=CreateCourseForm
	success_url='success'

class CourseListView(ListView):
	template_name='course_list.html'
	model=CourseModel
	context_object_name='courselist'

class CourseDetailView(DetailView):
	template_name='course_detail.html'
	model=CourseModel

class LeaveTypeView(CreateView):
	template_name='leave_type.html'
	form_class=leavetypeForm

class EditCourse(UpdateView):
    model = CourseModel
    fields = ['course_name','Duration','Description','Image','syllabus']
    template_name='edit_course.html'
    success_url='/courselist'














