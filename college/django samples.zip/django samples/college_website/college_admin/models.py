# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.db import models

# Create your models here.

class CourseModel(models.Model):
	course_name = models.CharField(max_length=100)
	Duration = models.CharField(max_length=10)
	Description = models.TextField(max_length=700)
	Image = models.ImageField(upload_to='media/pics/')
	syllabus = models.FileField(upload_to='media/files')
	created_on = models.DateTimeField(auto_now = True)

	def __str__(self):
		return(self.course_name)

class leavetype(models.Model):
	leave_type = models.CharField(max_length=50)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return(self.leave_type)