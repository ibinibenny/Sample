from django import forms
from college_admin.models import CourseModel,leavetype

class CreateCourseForm(forms.ModelForm):
	class Meta:
		model=CourseModel
		exclude=('created_on',)

class leavetypeForm(forms.ModelForm):
	class Meta:
		model=leavetype
		exclude=('created_on',)