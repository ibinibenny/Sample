# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('college_admin', '0001_initial'),
        ('faculty', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='LeaveModel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('leave_from', models.DateField()),
                ('leave_to', models.DateField()),
                ('no_of_days', models.IntegerField()),
                ('created_on', models.DateTimeField(auto_now=True)),
                ('leave_type', models.ForeignKey(to='college_admin.leavetype')),
            ],
        ),
    ]
