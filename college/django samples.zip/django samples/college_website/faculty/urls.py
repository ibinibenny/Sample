from django.conf.urls import url,include

from faculty.views import HomeView,FacultyHomeView,UserLogin,AboutView,FacultyRegisterView,FacultyListView,FacultyDetailView,SyllabusView,ChangePasswordView,CreateLeaveView
from django.contrib.auth import views as auth_views

from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings


urlpatterns = [
    url(r'^home/$',HomeView.as_view(),name='hme'),
    url(r'^facultyhome/$',FacultyHomeView.as_view(),name='facultyhme'),
    url(r'^about/$',AboutView.as_view(),name='abt'),
    url(r'^register/$',FacultyRegisterView.as_view(),name = 'f_reg'),
    url(r'^login/$',UserLogin.as_view(),name='log_in'),
    url(r'^list/$',FacultyListView.as_view(),name = 'facultylist'),
 	url(r'^detail/(?P<pk>[0-9]+)/$',FacultyDetailView.as_view(),name ='facultydetail'),
 	url(r'^download/syllabus/$',SyllabusView.as_view(),name = 'syllabus'),
 	url(r'^change/password/$', ChangePasswordView.as_view(), name='change_pwd'),
 	url(r'^applyleave/$', CreateLeaveView.as_view(), name='leave'),
 	
    ]


urlpatterns+=static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
