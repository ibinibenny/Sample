
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib
import urllib2
import json


from django.core.urlresolvers import reverse_lazy
from django.shortcuts import render,redirect,HttpResponse,render_to_response

from django.views.generic import TemplateView ,FormView,DetailView,ListView,View,CreateView
from faculty.forms import UserForm,Faculty_Registration_Form,leaveForm
from faculty.models import FacultyRegisterModel,LeaveModel
from college_admin.models import CourseModel

from django.conf import settings
from django.contrib import messages

# from faculty.models import Comment
# from faculty.forms import CommentForm


from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm

from django.contrib.auth import authenticate,login

# Create your views here.
class HomeView(TemplateView):
    template_name='home.html'

class AboutView(TemplateView):
    template_name='about us.html'

class FacultyHomeView(TemplateView):
    template_name='faculty_home.html'

class CreateCourseView(CreateView):
    template_name='leave.html'
    form_class=leaveForm
    success_url='success'

class FacultyRegisterView(FormView):
    template_name='faculty_registration.html'
    form_class=UserForm
    
    def get(self,request,*args, **kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = Faculty_Registration_Form()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form))

    def post(self,request,*args,**kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = Faculty_Registration_Form(self.request.POST,self.request.FILES)
        if (user_form.is_valid() and cust_form.is_valid()):
            return self.form_valid(user_form, cust_form)
        else:
            return self.form_invalid(user_form, cust_form)

    def get_success_url(self, **kwargs):
        return reverse_lazy('log_in')

    def form_valid(self, user_form, cust_form):
        self.object = user_form.save()
        self.object.is_staff=True
        self.object.save()
        p = cust_form.save(commit=False)
        p.user_obj = self.object
        p.save()
        return super(FacultyRegisterView, self).form_valid(user_form)
        
    def form_invalid(self, user_form, cust_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=cust_form))

    def comments(request):
        comments_list = Comment.objects.order_by('-created_at')

        if request.method == 'POST':
            form = CommentForm(request.POST)
            if form.is_valid():

                ''' Begin reCAPTCHA validation '''
                recaptcha_response = request.POST.get('g-recaptcha-response')
                url = 'https://www.google.com/recaptcha/api/siteverify'
                values = {
                    'secret': settings.GOOGLE_RECAPTCHA_SECRET_KEY,
                    'response': recaptcha_response
                }
                data = urllib.urlencode(values)
                req = urllib2.Request(url, data)
                response = urllib2.urlopen(req)
                result = json.load(response)
            ''' End reCAPTCHA validation '''

            if result['success']:
                form.save()
                messages.success(request, 'New comment added with success!')
            else:
                messages.error(request, 'Invalid reCAPTCHA. Please try again.')

            return redirect('log_in')
        

        return render(request, '.html', {'comments': comments_list, 'form': form})


class FacultyListView(ListView):
    template_name='faculty_list.html'
    model=FacultyRegisterModel
    context_object_name='facultylist'

class FacultyDetailView(DetailView):
    template_name='faculty_detail.html'
    model=FacultyRegisterModel

class SyllabusView(ListView):
    template_name='download_syllabus.html'
    model=CourseModel
    context_object_name='course_syllabus'


class ChangePasswordView(View):
    # @csrf_exempt
    def post(self,request):
        
        old_pwd = request.POST.get('old_password')
        new_pwd = request.POST.get('new_password')
        usr_obj = User.objects.get(username=request.user)
        if usr_obj.check_password(old_pwd):
            usr_obj.set_password(new_pwd)
            usr_obj.save()
            response = "Success"
        else:
            response = "Failed"
        return HttpResponse(json.dumps(response), content_type='json')

class CreateLeaveView(CreateView):
    template_name='leave_application.html'
    form_class=leaveForm
    success_url='success'

class UserLogin(View):
    def get(self,request):
        form=AuthenticationForm()
        context={'form':form}
        return render(request,'login.html',context)

    def post(self,request):
        a=request.POST.get('username')
        b=request.POST.get('password')
        user=authenticate(username=a,password=b)

        if user is not None :# and result['success']:
            login(request,user)
            if user.is_superuser == True and user.is_staff == True:
                return redirect('adminhome')
            if user.is_staff == True and user.is_superuser == False:
                return redirect('facultyhme')
        else:
            form=AuthenticationForm
            context={'form':form}
            return render(request,'login.html',context)


        

