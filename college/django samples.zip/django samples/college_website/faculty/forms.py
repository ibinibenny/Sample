from django import forms
from faculty.models import FacultyRegisterModel,LeaveModel
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import widgets


class Faculty_Registration_Form(forms.ModelForm):
	class Meta:
		model = FacultyRegisterModel
		exclude = ('created_on','user_obj')

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['first_name','last_name','email','username','password1','password2']

class DateInput(forms.DateInput):
	input_type = 'date'

class leaveForm(forms.ModelForm):
	class Meta:
		model=LeaveModel
		exclude=('created_on',)
		widgets = {
			'leave_from': DateInput(),
			'leave_to': DateInput(),
			}



		


		