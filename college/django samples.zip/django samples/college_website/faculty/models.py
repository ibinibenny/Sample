# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.db import models
from college_admin.models import CourseModel,leavetype
from django.contrib.admin.widgets import AdminDateWidget

# Create your models here.
class FacultyRegisterModel(models.Model):
	user_obj = models.OneToOneField(User)
	address = models.TextField(max_length=100)
	contact = models.CharField(max_length=11)
	Qualification= models.CharField(max_length=35)
	Department = models.ForeignKey(CourseModel)
	my_pic=models.ImageField(upload_to='media/pics/')
	resume=models.FileField(upload_to='media/files')
	created_on = models.DateTimeField(auto_now = True)
	
	def __unicode__(self):
		return u'%s %s' %(self.user_obj.first_name, self.user_obj.last_name)

class LeaveModel(models.Model):
	leave_from=models.DateField()
	leave_to=models.DateField()
	no_of_days=models.IntegerField()
	leave_type=models.ForeignKey(leavetype)
	created_on=models.DateTimeField(auto_now = True)

	def __str__(self):
		return (self.leave_type)