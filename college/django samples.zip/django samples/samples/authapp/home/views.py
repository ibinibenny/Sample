# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.views.generic import TemplateView,FormView,View
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render,HttpResponse,render_to_response, redirect
from django.contrib import auth
from django.contrib.auth.decorators import user_passes_test
# Create your views here.

def login(request):
    form =AuthenticationForm()
    if request.user.is_authenticated():
        if request.user.is_superuser:
            return redirect("/adminhome/")# or your url name
        if request.user.is_staff:
            return redirect("/home/")# or your url name


    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            # correct username and password login the user
            auth.login(request, user)
            if request.user.is_superuser:
                return redirect("/adminhome/")# or your url name
            if request.user.is_staff:
                return redirect("/home/")# or your url name

        else:
            messages.error(request, 'Error wrong username/password')
    context = {}
    context['form']=form

    return render(request, 'registration/login.html', context)



# class AdminHome(TemplateView):
#     template_name='home.html'

# class StaffHome(TemplateView):
#     template_name='staffhome.html'

@user_passes_test(lambda u: u.is_staff)
def StaffHome(request):
    context = {}
    return render(request, 'staffhome.html', context)

@user_passes_test(lambda u: u.is_superuser)
def AdminHome(request):
    context = {}
    return render(request, 'home.html', context)

