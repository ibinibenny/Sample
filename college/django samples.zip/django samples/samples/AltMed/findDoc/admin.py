# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import admin

from models import Category, SubCategory, LocationDetails, EducationDetails, PatientDetails, DoctorDetails, HospitalClinicDetails
# Register your models here.
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(LocationDetails)
admin.site.register(EducationDetails)
admin.site.register(PatientDetails)
admin.site.register(DoctorDetails)
admin.site.register(HospitalClinicDetails)