# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Category(models.Model):
	catgry_title = models.CharField(max_length=100)
	catgry_desription = models.TextField(max_length = 300,null =True, blank =True)
	created_on = models.DateTimeField(auto_now =True)

	class Meta:
		ordering = ['created_on']
		verbose_name = "Category"
		verbose_name_plural = "Categories"
		
	def __str__(self):
		return self.catgry_title


class SubCategory(models.Model):
	category = models.ForeignKey(Category)
	sub_catgry_title = models.CharField(max_length=100)
	sub_catgry_desription = models.TextField(max_length = 300,null =True, blank =True)
	created_on = models.DateTimeField(auto_now =True)

	class Meta:
		ordering = ['created_on']
		verbose_name = "Subcategory"
		verbose_name_plural = "Subcategories"

	def __str__(self):
		return self.sub_catgry_title
		

class LocationDetails(models.Model):
	city_name = models.CharField(max_length=100)
	created_on = models.DateTimeField(auto_now = True)

	class  Meta:
		"""docstring for  Meta"""
		ordering = ['created_on']
		verbose_name = "Location"
		verbose_name_plural = 'Locations'
	
	def __str__(self):
		return self.city_name


class EducationDetails(models.Model):
	qualification = models.CharField(max_length=100,unique = True)
	created_on = models.DateTimeField(auto_now=True)

	class  Meta:
		"""docstring for  Meta"""
		ordering = ['created_on']
		verbose_name = "Educational Qualification"
		verbose_name_plural = 'Educational Qualifications'
	
	def __str__(self):
		return self.qualification


class PatientDetails(models.Model):
	user = models.OneToOneField(User,related_name='patient_usr')
	contact = models.IntegerField(default = 0,unique=True)
	created_on = models.DateTimeField(auto_now =True)

	class Meta:
		ordering = ['created_on']
		verbose_name = "Patient"
		verbose_name_plural = "Patients"


class DoctorDetails(models.Model):
	user = models.OneToOneField(User,related_name='doctr_usr')
	contact = models.IntegerField(default=0,unique=True)
	address = models.TextField(max_length = 300,null =True, blank =True)
	doctr_category = models.ForeignKey(Category)
	doctr_sub_category = models.ForeignKey(SubCategory)
	qualification = models.ForeignKey(EducationDetails)
	work_location = models.ForeignKey(LocationDetails)
	license_no =  models.CharField(max_length=40)
	created_on = models.DateTimeField(auto_now =True)

	class Meta:
		"""docstring for Meta"""
		ordering = ['created_on']
		verbose_name = "Doctor"
		verbose_name_plural = "Doctors"


class HospitalClinicDetails(models.Model):
	user = models.OneToOneField(User,related_name='hsptal_usr')
	contact = models.IntegerField(default=0,unique=True)
	address = models.TextField(max_length = 300,null =True, blank =True)
	hsptal_category = models.ForeignKey(Category)
	hsptal_sub_category = models.ForeignKey(SubCategory)
	work_location = models.ForeignKey(LocationDetails)
	license_no =  models.CharField(max_length=40)
	created_on = models.DateTimeField(auto_now =True)

	class Meta:
		"""docstring for Meta"""
		ordering = ['created_on']
		verbose_name = "Hospital/Clinic"
		verbose_name_plural = "Hospitals/Clinics"