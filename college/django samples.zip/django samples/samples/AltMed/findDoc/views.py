# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

from models import LocationDetails, Category, SubCategory, EducationDetails, PatientDetails, DoctorDetails, HospitalClinicDetails
from serializers import CategorySerializer, SubCategorySerializer, LocationSerializer, QualificationSerializer
from serializers import DoctorSerializer, HospitalClinicSerializer, PatientSerializer
# Create your views here.

class GetAllLocations(APIView):
	""" API for fetching all locations """
	def get(self,request,format=None):
		location_obj = LocationDetails.objects.all()
		data = {}
		if location_obj:
			loctn_ser = LocationSerializer(location_obj, many=True)
			data['location'] = loctn_ser.data
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "LOCATIONS FETCHED"
			response = Response(data,status=status.HTTP_200_OK)
		else:
			data['location'] = ""
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "LOCATIONS NOT FOUND"
			response = Response(data,status=status.HTTP_200_OK)
		return response

		
class GetAllCategory(APIView):
	""" API for fetching all categories """
	def get(self,request,format=None):
		cat_obj = Category.objects.all()
		data = {}
		if cat_obj:
			catgry_ser = CategorySerializer(cat_obj, many=True)
			data['category'] = catgry_ser.data
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "CATEGORIES FETCHED"
			response = Response(data,status=status.HTTP_200_OK)
		else:
			data['category'] = ""
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "CATEGORIES NOT FOUND"
			response = Response(data,status=status.HTTP_200_OK)
		return response


class GetAllSubCategory(APIView):
	"""API for fetching all subcategories under selected category"""
	def post(self,request,format = None):
		request.POST._mutable = True
		category = request.data.get('category')
		try:
			catgry_obj = Category.objects.get(catgry_title=category)
		except Exception:
			catgry_obj = None
		sub_catgry_obj = SubCategory.objects.filter(category=catgry_obj)
		data = {}
		if sub_catgry_obj.count()>0:
			sub_cat_ser = SubCategorySerializer(sub_catgry_obj, many=True)
			data['sub_category'] = sub_cat_ser.data
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "SUBCATEGORIES FOUND"
			response = Response(data,status=status.HTTP_200_OK)
		else:
			data['sub_category'] = ""
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "SUBCATEGORIES NOT FOUND"
			response = Response(data,status=status.HTTP_200_OK)
		return response


class GetAllEducationalDetails(APIView):
	"""API for fetching all Educational Details"""
	def get(self,request,format = None):
		edu_obj = EducationDetails.objects.all()
		data = {}
		if edu_obj.count()>0:
			edu_ser = QualificationSerializer(edu_obj, many=True)
			data['Qualifications'] = edu_ser.data
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "QUALIFICATIONS FETCHED"
			response = Response(data,status=status.HTTP_200_OK)
		else:
			data['Qualifications'] = ""
			data['ErrorStatus'] = "HTTP_200_OK"
			data['ErrorCode'] = "200"
			data["ErrorDescription"] = "QUALIFICATIONS NOT FOUND"
			response = Response(data,status=status.HTTP_200_OK)
		return response


class NewRegistration(APIView):
	"""View for Registering Patients, Doctors, and Hospitals"""
	"""user_type = 0 (Seekers/Patients)"""
	"""user_type = 1 (Doctors)"""
	"""user_type = 2 (Hospitals/Clinics)"""
	def post(self, request, format=None):
		request.POST._mutable = True
		user_type = request.data.get('user_type')
		data = {}

		if user_type:
			try:
				fname = request.data.get('first_name').strip()
			except Exception:
				fname = None
			try:
				lname = request.data.get('last_name').strip()
			except Exception:
				lname = fname
			try:
				contact = request.data.get('contact')
			except Exception:
				contact = None
			try:
				email = request.data.get('email')
			except Exception:
				email = None
			try:
				password = request.data.get('password')
			except Exception:
				password = None
			try:
				catgry_name = request.data.get('category').strip()
			except Exception:
				catgry_name = None
			try:
				sub_catgry_name = request.data.get('sub_category').strip()
			except Exception:
				sub_catgry_name = None
			try:
				qualfctn = request.data.get('qualification').strip()
			except Exception:
				qualfctn = None
			try:
				address = request.data.get('address').strip()
			except Exception:
				address = None
			try:
				location = request.data.get('location').strip()
			except Exception:
				location = None
			try:
				license_no = request.data.get('license_no').strip()
			except Exception:
				license_no = None

		
			if request.data.get('username'):
				username = request.data.get('username')
			else:
				username = request.data.get('contact')

			if request.data.get('last_name'):
				lname = request.data.get('last_name')
			else:
				lname = request.data.get('first_name')

			if fname and username and email:
				try:
					user_obj = User.objects.get(username=username)
				except Exception:
					user_obj = None

				if user_obj:
					data["ErrorStatus"] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
					data['ErrorCode'] = "203"
					data["ErrorDescription"] = "USER ALREADY REGISTERED"
					response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)

				else:
					if user_type == '0':
						try:
							user_obj = User.objects.create(username=username, first_name=fname, last_name=lname,
									 email=email)
							user_obj.set_password(password)
							user_obj.save()
						except Exception:
							user_obj = None
						try:
							patient = PatientDetails.objects.create(user=user_obj,contact=contact)
						except Exception:
							patient = None
						data['ErrorStatus'] = "HTTP_201_CREATED"
						data['ErrorCode'] = "201"
						data["ErrorDescription"] = "SUCCESSFULLY REGISTERED"
						response = Response(data,status=status.HTTP_201_CREATED)

					elif user_type == '1':
						try:
							cat_obj = Category.objects.get(catgry_title=catgry_name)
						except Exception:
							cat_obj = None
						if cat_obj!=None:
							try:
								subcat_obj = SubCategory.objects.get(category=cat_obj,
									sub_catgry_title=sub_catgry_name)
							except Exception:
								subcat_obj = None
							try:
								loc_obj = LocationDetails.objects.get(city_name=location)
							except Exception:
								loc_obj = None
							try:
								edu_obj = EducationDetails.objects.get(qualification=qualfctn)
							except Exception:
								edu_obj = None

							if subcat_obj!=None:
								if loc_obj!=None:
									if edu_obj !=None:
										try:
											user_obj = User.objects.create(username=username, first_name=fname, last_name=lname,
												 email=email)
											user_obj.set_password(password)
											user_obj.save()
										except Exception:
											user_obj = None
										try:
											doctor = DoctorDetails.objects.create(user=user_obj,contact=contact,address=address,
												work_location=loc_obj,qualification = edu_obj,doctr_category=cat_obj,doctr_sub_category=subcat_obj,
												license_no=license_no)
										except Exception:
											doctor = None
										data['ErrorStatus'] = "HTTP_201_CREATED"
										data['ErrorCode'] = "201"
										data["ErrorDescription"] = "SUCCESSFULLY REGISTERED"
										response = Response(data,status=status.HTTP_201_CREATED)
									else:
										data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
										data['ErrorCode'] = "203"
										data["ErrorDescription"] = "INVALID QUALIFICATION"
										response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
								else:
									data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
									data['ErrorCode'] = "203"
									data["ErrorDescription"] = "INVALID LOCATION"
									response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)

							else:
								data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
								data['ErrorCode'] = "203"
								data["ErrorDescription"] = "INVALID SUB-CATEGORY"
								response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
						else:
							data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
							data['ErrorCode'] = "203"
							data["ErrorDescription"] = "INVALID CATEGORY"
							response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
						
					else:
						try:
							cat_obj = Category.objects.get(catgry_title=catgry_name)
						except Exception:
							cat_obj = None
						if cat_obj!=None:
							try:
								subcat_obj = SubCategory.objects.get(category=cat_obj,
									sub_catgry_title=sub_catgry_name)
							except Exception:
								subcat_obj = None
							try:
								loc_obj = LocationDetails.objects.get(city_name=location)
							except Exception:
								loc_obj = None

							if subcat_obj != None:
								if loc_obj!=None:
									try:
										user_obj = User.objects.create(username=username, first_name=fname, last_name=lname,
												 email=email)
										user_obj.set_password(password)
										user_obj.save()
									except Exception:
										user_obj = None

									try:
										hospital = HospitalClinicDetails.objects.create(user=user_obj,
											contact=contact,address=address,work_location=loc_obj,
											hsptal_category=cat_obj,hsptal_sub_category=subcat_obj,
											license_no=license_no)
									except Exception:
										hospital = None

									data['ErrorStatus'] = "HTTP_201_CREATED"
									data['ErrorCode'] = "201"
									data["ErrorDescription"] = "SUCCESSFULLY REGISTERED"
									response = Response(data,status=status.HTTP_201_CREATED)
								else:
									data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
									data['ErrorCode'] = "203"
									data["ErrorDescription"] = "INVALID LOCATION"
									response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
							else:
								data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
								data['ErrorCode'] = "203"
								data["ErrorDescription"] = "INVALID SUB-CATEGORY"
								response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
						else:
							data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
							data['ErrorCode'] = "203"
							data["ErrorDescription"] = "INVALID CATEGORY"
							response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
			else:
				# data = {}
				data['ErrorStatus'] = "HTTP_500_INTERNAL_SERVER_ERROR"
				data['ErrorCode'] = "500"
				data["ErrorDescription"] = "SOMETHING WENT WRONG, CHECK USER_DETAILS, MISSING MANDATORY FIELDS"
				response = Response(data,status=status.HTTP_400_BAD_REQUEST)
		else:
			# data = {}
			data['ErrorStatus'] = "HTTP_500_INTERNAL_SERVER_ERROR"
			data['ErrorCode'] = "500"
			data["ErrorDescription"] = "SOMETHING WENT WRONG, CHECK USER_TYPE"
			response = Response(data, status=status.HTTP_400_BAD_REQUEST)

		return response


class LoginCheck(APIView):
	"""API for LOGIN """
	def post(self,request,format=None):
		request.POST._mutable = True
		try:
			uname = request.data.get('username').strip()
		except Exception:
			uname = None
		try:
			pwrd = request.data.get('password').strip()
		except Exception:
			pwrd = None
		data = {}
		if uname!=None and pwrd!=None:
			if len(uname)!=0 and len(pwrd)!=0:
  				user1 = authenticate(username = uname, password = pwrd)
  				if user1!=None:
  					data['ErrorStatus'] = "HTTP_202_REQUEST_ACCEPTED"
					data['ErrorCode'] = "202"
					data["ErrorDescription"] = "SUCCESSFULLY AUTHENTICATED"
					response = Response(data, status=status.HTTP_400_BAD_REQUEST)
				else:
					data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
					data['ErrorCode'] = "203"
					data["ErrorDescription"] = "SOMETHING WENT WRONG, INVALID LOGIN"
					response = Response(data, status=status.HTTP_400_BAD_REQUEST)
			else:

				data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
				data['ErrorCode'] = "203"
				data["ErrorDescription"] = "SOMETHING WENT WRONG, INVALID LOGIN"
				response = Response(data, status=status.HTTP_400_BAD_REQUEST)
		else:
			data['ErrorStatus'] = "HTTP_500_INTERNAL_SERVER_ERROR"
			data['ErrorCode'] = "500"
			data["ErrorDescription"] = "SOMETHING WENT WRONG, INVALID PAYLOAD"
			response = Response(data, status=status.HTTP_400_BAD_REQUEST)
		return response


class GetAllDoctorHospitals(APIView):
	"""API for fetching All Doctors and Hospital or Clinic Details"""

	def post(self,request,format=None):
		request.POST._mutable = True
		try:
			category = request.data.get('category').strip()
		except Exception:
			category = None
		try:
			sub_category = request.data.get('sub_category').strip()
		except Exception:
			sub_category = None
		try:
			location = request.data.get('location').strip()
		except Exception:
			location = None

		data = {}

		try:
			catgry_obj = Category.objects.get(catgry_title=category)
		except Exception:
			catgry_obj = None

		if catgry_obj!=None:
			try:
				sub_catgry_obj = SubCategory.objects.get(category=catgry_obj,sub_catgry_title=sub_category)
			except Exception:
				sub_catgry_obj = None

			if sub_catgry_obj!=None:
				try:
					loc_obj = LocationDetails.objects.get(city_name = location)
				except Exception:
					loc_obj = None
				if loc_obj!=None:
					try:
						doctr_obj = DoctorDetails.objects.filter(doctr_category=catgry_obj,
							doctr_sub_category=sub_catgry_obj,work_location=loc_obj)
					except Exception:
						doctr_obj = None
					if doctr_obj.count()>0:
						dctr_ser = DoctorSerializer(doctr_obj, many=True)
						data['Doctors'] = dctr_ser.data
						data["ErrorDescription"] = "Workers found"
					else:
						data['Doctors'] = ""
					try:
						hosptal_obj = HospitalClinicDetails.objects.filter(hsptal_category=catgry_obj,
							hsptal_sub_category=sub_catgry_obj,work_location=loc_obj)
					except Exception:
						hosptal_obj = None

					if doctr_obj.count()==0 and hosptal_obj.count()==0:
						data["ErrorDescription"] = "Workers not found"

					if hosptal_obj.count()>0:
						hsptal_ser = HospitalClinicSerializer(hosptal_obj, many=True)
						data['Hospitals'] = hsptal_ser.data
						data["ErrorDescription"] = "Workers found"
					else :
						data['Hospitals'] = ""

					data['ErrorStatus'] = "HTTP_200_OK"
					data['ErrorCode'] = "200"
					# data["ErrorDescription"] = "Workers not found"
					response = Response(data,status=status.HTTP_200_OK)
				else:
					data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
					data['ErrorCode'] = "203"
					data["ErrorDescription"] = "INVALID LOCATION"
					response = Response(data,status=status.HTTP_200_OK)
			else:
				data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
				data['ErrorCode'] = "203"
				data["ErrorDescription"] = "INVALID SUB_CATEGORY"
				response = Response(data,status=status.HTTP_200_OK)
		else:
			data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
			data['ErrorCode'] = "203"
			data["ErrorDescription"] = "INVALID CATEGORY"
			response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
		
		return response


class GetProfileDetails(APIView):
	"""API for Fetching Profile Details"""
	def post(self,request,format=None):
		request.POST._mutable = True
		try:
			user_id = request.data.get('user_id').strip()
		except Exception:
			user_id = None
		try:
			usr_status = request.data.get('user_type').strip()
		except Exception:
			usr_status = None

		data = {}
		if user_id != None and usr_status !=None:
			if len(user_id)!=0 and len(usr_status)!=0:
				try:
					usr_obj = User.objects.get(username=user_id)
				except Exception:
					usr_obj = None
				if usr_obj !=None:
					if usr_status=='0':
						try:
							pat_obj = PatientDetails.objects.filter(user=usr_obj)
						except Exception:
							pat_obj = None
						if pat_obj!=None:
							patient_ser = PatientSerializer(pat_obj, many=True)
							data['Profile_Details'] = patient_ser.data
						else:
							data['Profile_Details'] = " "
					elif usr_status == '1':
						try:
							doc_obj = DoctorDetails.objects.filter(user=usr_obj)
						except Exception:
							doc_obj = None
						if doc_obj!=None:
							doc_ser = DoctorSerializer(doc_obj, many=True)
							data['Profile_Details'] = doc_ser.data
						else:
							data['Profile_Details'] = " "
					else:
						try:
							hospital_obj = HospitalClinicDetails.objects.filter(user=usr_obj)
						except Exception:
							hospital_obj = None
						if hospital_obj!=None:
							hospital_ser = HospitalClinicSerializer(hospital_obj, many=True)
							data['Profile_Details'] = hospital_ser.data
						else:
							data['Profile_Details'] = " "

					data['ErrorStatus'] = "HTTP_200_OK"
					data['ErrorCode'] = "200"
					data["ErrorDescription"] = "Profile Details Here"
					response = Response(data,status=status.HTTP_203_NON_AUTHORITATIVE_INFORMATION)
				else:
					data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
					data['ErrorCode'] = "203"
					data["ErrorDescription"] = "SOMETHING WENT WRONG, INVALID LOGIN"
					response = Response(data, status=status.HTTP_400_BAD_REQUEST)
			else:
				data['ErrorStatus'] = "HTTP_203_NON_AUTHORITATIVE_INFORMATION"
				data['ErrorCode'] = "203"
				data["ErrorDescription"] = "SOMETHING WENT WRONG, INVALID LOGIN"
				response = Response(data, status=status.HTTP_400_BAD_REQUEST)
		else:
			data['ErrorStatus'] = "HTTP_500_INTERNAL_SERVER_ERROR"
			data['ErrorCode'] = "500"
			data["ErrorDescription"] = "SOMETHING WENT WRONG, INVALID PAYLOAD"
			response = Response(data, status=status.HTTP_400_BAD_REQUEST)
		
		return response

		

