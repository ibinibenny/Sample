from django.conf.urls import url,include
from django.contrib import admin

from views import GetAllLocations, GetAllCategory, GetAllSubCategory, GetAllEducationalDetails
from views import NewRegistration, LoginCheck, GetAllDoctorHospitals, GetProfileDetails

urlpatterns = [
    url(r'^locations', GetAllLocations.as_view(),name="get_all_locations"),
    url(r'^category', GetAllCategory.as_view(),name="get_all_category"),
    url(r'^subcategory', GetAllSubCategory.as_view(), name="get_all_sub_category"),
    url(r'^qualifications', GetAllEducationalDetails.as_view(), name="get_all_qualifications"),
    url(r'^register', NewRegistration.as_view(),name='register'),
    url(r'^login', LoginCheck.as_view(),name='login'),
    url(r'^get/workers',GetAllDoctorHospitals.as_view(), name = "get_doct_hospital"),
    url(r'^get/profile',GetProfileDetails.as_view(), name = "get_profile"),

]