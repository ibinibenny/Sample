from rest_framework import serializers
from django.contrib.auth.models import User


from models import Category,SubCategory, LocationDetails, EducationDetails, PatientDetails, HospitalClinicDetails, DoctorDetails


class LocationSerializer(serializers.ModelSerializer):
	class Meta:
		model = LocationDetails
		exclude = ('created_on',)


class CategorySerializer(serializers.ModelSerializer):
	"""Serializer for Category"""
	class Meta:
		model = Category
		exclude = ('created_on',)
		

class SubCategorySerializer(serializers.ModelSerializer):
	"""Serializer for Subcategory"""
	category = CategorySerializer(read_only = True)
	
	class Meta:
		model = SubCategory
		exclude = ('created_on',)
		
class QualificationSerializer(serializers.ModelSerializer):
	"""Serializer for EducationalQualifications"""
	
	class Meta:
		model = EducationDetails
		exclude = ('created_on',)


class UserSerializer(serializers.ModelSerializer):
	""" Serializer for User"""

	class  Meta:
		model = User
		fields = ('first_name','last_name','email',)
			

class PatientSerializer(serializers.ModelSerializer):
	"""Serializer for EducationalQualifications"""
	user = UserSerializer(read_only = True)

	class Meta:
		model = PatientDetails
		exclude = ('created_on',)


class DoctorSerializer(serializers.ModelSerializer):
	"""Serializer for EducationalQualifications"""
	user = UserSerializer(read_only = True)

	class Meta:
		model = DoctorDetails
		exclude = ('created_on',)


class HospitalClinicSerializer(serializers.ModelSerializer):
	"""Serializer for EducationalQualifications"""
	user = UserSerializer(read_only = True)

	class Meta:
		model = HospitalClinicDetails
		exclude = ('created_on',)