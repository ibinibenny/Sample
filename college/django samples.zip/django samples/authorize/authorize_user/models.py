from django.db import models

from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class RegisterModel(models.Model):
	user_obj = models.OneToOneField(User)
	created_on = models.DateTimeField(auto_now = True)

	def __unicode__(self):
		return u'%s %s' %(self.user_obj.first_name, self.user_obj.last_name)

class CardRegistrationModel(models.Model):
	Card_Holder=models.CharField(max_length=15)
	Card_Number=models.CharField(max_length=16)
	Expiry_Date=models.CharField(max_length=11)
	CVV=models.CharField(max_length=4)
	Email=models.EmailField()
	created_on = models.DateTimeField(auto_now = True)

	def __str__(self):
		return (self.Card_Holder)


