from django.conf.urls import url,include

from authorize_user.views import HomeView,RegisterView,UserLogin,AdminHomeView,auth_HomeView,CardRegisterView

urlpatterns=[
	
	url(r'^authorizehome/$',auth_HomeView.as_view(),name='auth_home'),
	url(r'^home/$',HomeView.as_view(),name='home'),
	url(r'^adminhome/$',AdminHomeView.as_view(),name='adminhome'),
	url(r'^register/$',RegisterView.as_view(),name='reg'),
	url(r'^login/$',UserLogin.as_view(),name='log_in'),
	url(r'^cardregister/$',CardRegisterView.as_view(),name='card_reg'),

]