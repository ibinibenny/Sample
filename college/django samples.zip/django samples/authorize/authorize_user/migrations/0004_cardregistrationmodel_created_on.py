# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime
from django.utils.timezone import utc


class Migration(migrations.Migration):

    dependencies = [
        ('authorize_user', '0003_auto_20190624_0714'),
    ]

    operations = [
        migrations.AddField(
            model_name='cardregistrationmodel',
            name='created_on',
            field=models.DateTimeField(default=datetime.datetime(2019, 6, 24, 7, 15, 9, 58173, tzinfo=utc), auto_now=True),
            preserve_default=False,
        ),
    ]
