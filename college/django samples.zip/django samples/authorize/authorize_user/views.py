from django.shortcuts import render,HttpResponse,render_to_response,redirect

from django.core.urlresolvers import reverse_lazy
from django.views.generic import TemplateView,FormView,View,CreateView
from authorize_user.forms import UserForm,RegistrationForm,CardRegistrationForm
from django.contrib.auth.forms import AuthenticationForm

from django.contrib.auth import authenticate,login
import constants
import os, sys
import imp

from authorizenet import apicontractsv1
from authorizenet.apicontrollers import *
constants = imp.load_source('modulename', 'constants.py')
import random

# Create your views here.

class HomeView(TemplateView):
    template_name='home.html'

class AdminHomeView(TemplateView):
    template_name='admin_home.html'

class auth_HomeView(TemplateView):
    template_name='authorize_home.html'

class RegisterView(FormView):
    template_name='register.html'
    form_class=UserForm
    
    def get(self,request,*args, **kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = RegistrationForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form))

    def post(self,request,*args,**kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = RegistrationForm(self.request.POST,self.request.FILES)
        if (user_form.is_valid() and cust_form.is_valid()):
            return self.form_valid(user_form, cust_form)
        else:
            return self.form_invalid(user_form, cust_form)

    def get_success_url(self, **kwargs):
        return reverse_lazy('log_in')

    def form_valid(self, user_form, cust_form):
        self.object = user_form.save()
        self.object.is_staff=True
        self.object.save()
        p = cust_form.save(commit=False)
        p.user_obj = self.object
        p.save()
        return super(RegisterView, self).form_valid(user_form)
        
    def form_invalid(self, user_form, cust_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=cust_form))

class UserLogin(View):
    def get(self,request):
        form=AuthenticationForm()
        context={'form':form}
        return render(request,'login.html',context)

    def post(self,request):
        a=request.POST.get('username')
        b=request.POST.get('password')
        user=authenticate(username=a,password=b)

        if user is not None :# and result['success']:
            login(request,user)
            if user.is_superuser == True and user.is_staff == True:
                return redirect('adminhome')
            if user.is_staff == True and user.is_superuser == False:
                return redirect('home')
        else:
            form=AuthenticationForm
            context={'form':form}
            return render(request,'login.html',context)

class CardRegisterView(CreateView):
    template_name='card_register.html'
    form_class=CardRegistrationForm

    def create_customer_profile():
        username=request.POST.get('username')
        name=request.POST.get('first_name')
        email=request.POST.get('email')
        merchantAuth = apicontractsv1.merchantAuthenticationType()
        merchantAuth.name = constants.apiLoginId
        merchantAuth.transactionKey = constants.transactionKey


        createCustomerProfile = apicontractsv1.createCustomerProfileRequest()
        createCustomerProfile.merchantAuthentication = merchantAuth
        createCustomerProfile.profile = apicontractsv1.customerProfileType(username,name,email)

        controller = createCustomerProfileController(createCustomerProfile)
        controller.execute()

        response = controller.getresponse()

        if (response.messages.resultCode=="Ok"):
            print("Successfully created a customer profile with id: %s" % response.customerProfileId)
        else:
            print("Failed to create customer payment profile %s" % response.messages.message[0]['text'].text)

        return response

        env = Environment(loader=FileSystemLoader('templates'))
        template = env.get_template('output3.html')
        output_from_parsed_template = template.render(trans_id = response.customerProfileId,desc1 = error)
        # return response
        try:
           fh = open("output3.html", "w")
           fh.write(output_from_parsed_template)
        except IOError:
           print ("<br>Error: can\'t find file or read data")
        else:
           print ("Written content in the file successfully")
        print('Content-type:text/html\n\n')
        redirectURL = "http://pyb43.specind.net/output3.html"
        print('<html>')
        print('<head>')
        print('<meta http-equiv="refresh" content="0;url='+str(redirectURL)+'" />') 
        print('</head>')
        print('</html>')    


