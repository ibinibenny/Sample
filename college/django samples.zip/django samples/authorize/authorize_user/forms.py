from django import forms
from authorize_user.models import RegisterModel,CardRegistrationModel
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class RegistrationForm(forms.ModelForm):
	class Meta:
		model = RegisterModel
		exclude = ('created_on','user_obj')

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['first_name','last_name','email','username','password1','password2']



class CardRegistrationForm(forms.ModelForm):
	class Meta:
		model = CardRegistrationModel
		fields = ['Card_Holder','Card_Number','Expiry_Date','CVV','Email']
