#Authorize.net



api_login_name= "5gKkh86FJ6"
transaction_key= "446F2aq98GKbK8vE"
customerProfileId= '1919212816'
customerPaymentProfileId = '1832199925'
merch_id = '703923'
merch_card_number ="4111111111111111"
card_exp_date = "2020-12"