# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('app1', '0004_auto_20190803_1037'),
    ]

    operations = [
        migrations.CreateModel(
            name='FacultyRegisterModel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('address', models.TextField(max_length=100)),
                ('contact', models.CharField(max_length=11)),
                ('Qualification', models.CharField(max_length=35)),
                ('my_pic', models.ImageField(upload_to=b'media/pics/')),
                ('resume', models.FileField(upload_to=b'media/files')),
                ('created_on', models.DateTimeField(auto_now=True)),
                ('user_obj', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AlterField(
            model_name='newmodel',
            name='my_pic',
            field=models.ImageField(default=b'media/998.jpg', upload_to=b'pics/'),
        ),
        migrations.AlterField(
            model_name='newmodel',
            name='resume',
            field=models.FileField(default=b'media/SRS.pdf', upload_to=b'files/'),
        ),
    ]
