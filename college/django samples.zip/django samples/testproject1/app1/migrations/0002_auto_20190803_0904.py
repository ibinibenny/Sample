# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('app1', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='newmodel',
            name='my_pic',
            field=models.ImageField(default=b'/home/suja/Pictures/998.jpg', upload_to=b'media/pics/'),
        ),
        migrations.AddField(
            model_name='newmodel',
            name='resume',
            field=models.FileField(default=b'/home/suja/Downloads/SRS.pdf', upload_to=b'media/files'),
        ),
    ]
