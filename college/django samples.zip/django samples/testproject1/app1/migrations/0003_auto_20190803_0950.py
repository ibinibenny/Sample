# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('app1', '0002_auto_20190803_0904'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='newmodel',
            name='my_pic',
        ),
        migrations.RemoveField(
            model_name='newmodel',
            name='resume',
        ),
    ]
