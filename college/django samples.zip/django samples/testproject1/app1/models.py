from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class NewModel(models.Model):
	name=models.CharField(max_length=25)
	address = models.TextField(max_length=100)
	contact = models.CharField(max_length=11)
	Qualification= models.CharField(max_length=35)
	my_pic=models.ImageField(upload_to='pics/',default='media/998.jpg')
	resume=models.FileField(upload_to='files/', default='media/SRS.pdf')
	created_on=models.DateTimeField(auto_now=True)

	def __str__(self):
		return str(self.name)

class FacultyRegisterModel(models.Model):
	user_obj = models.OneToOneField(User)
	address = models.TextField(max_length=100)
	contact = models.CharField(max_length=11)
	Qualification= models.CharField(max_length=35)
	my_pic=models.ImageField(upload_to='media/pics/')
	resume=models.FileField(upload_to='media/files')
	created_on = models.DateTimeField(auto_now = True)
	
	def __unicode__(self):
		return u'%s %s' %(self.user_obj.first_name, self.user_obj.last_name)