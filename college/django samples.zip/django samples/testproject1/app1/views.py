from django.shortcuts import render,redirect,HttpResponse,render_to_response
from django.core.urlresolvers import reverse_lazy

from django.views.generic import TemplateView,CreateView,ListView,UpdateView,DetailView,FormView
from app1.forms import NewForm,UserForm,Faculty_Registration_Form
from app1.models import NewModel
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
# Create your views here.
class HomeView(TemplateView):
	template_name="home.html"

def AboutView(request):                        
    return render(request,'about.html')

class NewView(CreateView):
	template_name='new.html'
	form_class=NewForm
	success_url='/create/'


class NewListView(ListView):
	template_name='list.html'
	model=NewModel
	context_object_name='newlist'

class NewUpdateView(UpdateView):
	template_name='edit.html'
	model=NewModel
	fields=['name','Qualification','contact','address']
	success_url='/list/'

class NewDetailView(DetailView):
	template_name='detail.html'
	model=NewModel

class FacultyRegisterView(FormView):
    template_name='register.html'
    form_class=UserForm
    
    def get(self,request,*args, **kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = Faculty_Registration_Form()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form))

    def post(self,request,*args,**kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = Faculty_Registration_Form(self.request.POST,self.request.FILES)
        if (user_form.is_valid() and cust_form.is_valid()):
            return self.form_valid(user_form, cust_form)
        else:
            return self.form_invalid(user_form, cust_form)

    def get_success_url(self, **kwargs):
        return reverse_lazy('log_in')

    def form_valid(self, user_form, cust_form):
        self.object = user_form.save()
        self.object.is_staff=True
        self.object.save()
        p = cust_form.save(commit=False)
        p.user_obj = self.object
        p.save()
        return super(FacultyRegisterView, self).form_valid(user_form)
        
    def form_invalid(self, user_form, cust_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=cust_form))
