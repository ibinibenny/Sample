from django.conf.urls import  url
from app1.views import HomeView,NewView,NewListView,NewUpdateView,NewDetailView,FacultyRegisterView,AboutView
from django.contrib.auth import views as auth_views
urlpatterns = [
   
    url(r'^home/$',HomeView.as_view(),name='home'),
    url(r'^about/$',AboutView,name='create'),
    url(r'^create/$',NewView.as_view(),name='create'),
    url(r'^list/$',NewListView.as_view(),name='list'),
    url(r'^edit/(?P<pk>[0-9]+)/$',NewUpdateView.as_view(),name ='edit'),
    url(r'^detail/(?P<pk>[0-9]+)/$',NewDetailView.as_view(),name ='detail'),
    url(r'^register/$',FacultyRegisterView.as_view(),name = 'f_reg'),
    url(r'^login/$', auth_views.login, {'template_name': 'login.html'}, name='log_in'),
    url(r'^logout/$', auth_views.logout, {'template_name': 'home.html'}, name='logout'),
]

