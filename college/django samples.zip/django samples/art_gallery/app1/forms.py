from django import forms
from app1.models import RegisterModel,ArtModel
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class RegistrationForm(forms.ModelForm):
	class Meta:
		model = RegisterModel
		exclude = ('created_on','user_obj')

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['first_name','last_name','email','username','password1','password2']

class ArtRegistrationForm(forms.ModelForm):
	class Meta:
		model = ArtModel
		exclude = ('created_on','uploadedby')