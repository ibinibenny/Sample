from django.shortcuts import render

from django.views.generic import View,FormView
from app1.forms import UserForm,RegistrationForm,ArtRegistrationForm
from app1.models import ArtModel
from django.shortcuts import render,redirect,HttpResponse,render_to_response
from django.core.urlresolvers import reverse_lazy
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User

# Create your views here.

class HomeView(View):
	template_name="home.html"

	def get(self,request):
		return render(request,self.template_name)

class AdminHomeView(View):
	template_name="adminhome.html"

	def get(self,request):
		return render(request,self.template_name)


class RegisterView(FormView):
    template_name='register_login.html'
    form_class=UserForm
    
    def get(self,request,*args, **kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        cust_form = RegistrationForm()
        login_form = AuthenticationForm()
        return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form, form3=login_form))

    def post(self,request,*args,**kwargs):
            if request.method=='POST' and "signup_btn" in request.POST:
                self.object = None
                form_class = self.get_form_class()
                user_form = self.get_form(form_class)
                cust_form = RegistrationForm(self.request.POST,self.request.FILES)
                if (user_form.is_valid() and cust_form.is_valid()):
                    return self.form_valid(user_form, cust_form)
                else:
                    return self.form_invalid(user_form, cust_form)

            if request.method=='POST' and "login_btn" in request.POST:
                user = authenticate(username=request.POST['username'],password=request.POST["password"])
                print(user)
                if user != None:
                    login(request,user)
                    if user.is_superuser:
                        return redirect ("adminhome")
                    if user.is_staff:
                        return redirect ("home")
                else:
                    return redirect ("home")

    def get_success_url(self, **kwargs):
        return ("success")

    def form_valid(self, user_form, cust_form):
        self.object = user_form.save()
        print(self.object)
        self.object.is_staff=True
        self.object.save()
        
        p = cust_form.save(commit=False)
        p.user_obj = self.object
        p.save()
        return redirect ('home')
        
    def form_invalid(self, user_form, cust_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=cust_form,))



class ArtRegister(View):
    template_name='addart.html'
    
    def get(self,request):
        if request.user.is_authenticated():
            item_form=ArtRegistrationForm()
            context={
                'form':item_form
            }
            return render(request,self.template_name,context)
        else:
            return redirect("addart")


    def post(self,request):
        print(request.POST, request.FILES)
        art_name=request.POST.get("name")
        art_my_pic=request.FILES["my_pic"]
        n_user=request.user
        print(n_user)
        ArtModel.objects.create(name = art_name,my_pic = art_my_pic,uploadedby = n_user)
        return redirect ('addart')


class ArtList(View):
    template_name='art_list.html'

    def get(self,request):
        items=ArtModel.objects.all()
        users=User.objects.all()
        context={
        'items':items,
        'users':users,
        }
        return render(request,self.template_name,context)

class ArtDetail(View):
    template_name='art_detail.html'

    def get(self,request,pk):
        items=ArtModel.objects.all()
        users=User.objects.all()

        context={
        'items':items,
        'users':users,
        }

        return render(request,self.template_name,context)
 