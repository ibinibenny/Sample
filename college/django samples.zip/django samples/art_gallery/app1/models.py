from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class RegisterModel(models.Model):
	user_obj = models.OneToOneField(User)
	address = models.TextField(max_length=100)
	contact = models.CharField(max_length=11)
	created_on = models.DateTimeField(auto_now = True)

	def __unicode__(self):
		return u'%s %s' %(self.user_obj.first_name, self.user_obj.last_name)

class ArtModel(models.Model):
	name=models.CharField(max_length=100)
	my_pic=models.ImageField(upload_to='pics/')
	uploadedby=models.ForeignKey(User)
	created_on = models.DateTimeField(auto_now = True)


	def __str__(self):
		return (self.name)