from django.conf.urls import include, url
from app1.views import HomeView,RegisterView,AdminHomeView,RegisterView,ArtRegister,ArtList,ArtDetail

from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings

urlpatterns = [
    # Examples:
    # url(r'^$', 'art_gallery.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^home/$',HomeView.as_view(),name='home'),
    url(r'^adminhome/$',AdminHomeView.as_view(),name='adminhome'),
    url(r'^register/$',RegisterView.as_view(),name='reg'),
 
    # url(r'^list/$',ArtListView.as_view(),name='list'),
    url(r'^detail/(?P<pk>[0-9]+)/$',ArtDetail.as_view(),name='detail'),
    url(r'^addproduct/$',ArtRegister.as_view(),name='addart'),
    url(r'^list/$',ArtList.as_view(),name='list'),




]

urlpatterns = urlpatterns + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
