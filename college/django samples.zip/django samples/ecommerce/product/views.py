# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.views.generic import CreateView, ListView, UpdateView, DetailView, View

from product.forms import CategoryForm,ProductForm
from product.models import Product, Category

# Create your views here.
class ProductCreation(CreateView):
    template_name = "productcreate.html"
    form_class = ProductForm
    success_url = '/product/list'

class CategoryCreation(CreateView):
    template_name = "categorycreate.html"
    form_class = CategoryForm
    success_url = '/category/list'

class ProductList(ListView):
    template_name = "productlist.html"
    model = Product

class ProductUpdation(UpdateView):
    template_name = "productupdate.html"
    model = Product
    fields = ['name','price','category','description','img']
    success_url = '/product/list'

class ProductDetail(DetailView):
    template_name = "productdetail.html"
    model = Product

def category_list(request):
    cat_list = Category.objects.all()
    context = {
        'object_list': cat_list
    }
    return render(request, 'categories.html', context)

class CategorywiseProducts(View):
    template_name = "categorywiseproducts.html"

    def get(self,request,pk):
        categoryname = Category.objects.get(id=pk)
        pdts = Product.objects.filter(category=categoryname).filter(status=1)
        context = {
            'products':pdts,
            'category':categoryname,
        }
        return render(request, self.template_name, context)
