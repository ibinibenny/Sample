from django import forms

from product.models import Category,Product

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        exclude = ('status','created_date')

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        exclude = ('status','created_date')