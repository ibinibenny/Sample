from django.conf.urls import url

from product.views import ProductCreation, CategoryCreation, ProductList
from product.views import ProductUpdation,ProductDetail, CategorywiseProducts
from product import views

urlpatterns = [
    url(r'product/create', ProductCreation.as_view(), name="productcreation"),
    url(r'category/create', CategoryCreation.as_view(), name="categorycreation"),
    url(r'product/list', ProductList.as_view(), name="productlist"),
    url(r'product/update/(?P<pk>[0-9]+)', ProductUpdation.as_view(), name="productupdating"),
    url(r'product/detail/(?P<pk>[0-9]+)', ProductDetail.as_view(), name="productdetailing"),
    url(r'category/list', views.category_list, name="categories"),
    url(r'category/products/(?P<pk>[0-9]+)', CategorywiseProducts.as_view(),name="categoryproductsonly"),
]