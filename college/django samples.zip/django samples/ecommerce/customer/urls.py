from django.conf.urls import url
from django.contrib.auth import views as auth_views
from customer.views import RegisterCustomer

urlpatterns = [
    url(r'login', auth_views.login, name="login"),
    url(r'logout', auth_views.logout, name="logout"),
    url(r'register', RegisterCustomer.as_view(), name="registercustomer"),
]