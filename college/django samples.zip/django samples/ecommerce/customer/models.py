# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class UserRemainingDetails(models.Model):
    user_data = models.OneToOneField(User)
    address = models.CharField(max_length=50)
    ph_no = models.IntegerField()
    status = models.IntegerField(default=1)
    created_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.user_data.username
