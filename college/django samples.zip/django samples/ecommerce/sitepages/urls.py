from django.conf.urls import url

from sitepages.views import HomeView

urlpatterns = [
    url(r'home',HomeView.as_view(),name="home")
]