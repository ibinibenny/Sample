# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from django.views.generic import View

from .forms import StudentForm
from .models import Student
# Create your views here.


#TemplateView
class HomeView(View):
    template_name = "home.html"

    def get(self,request):
        return render(request, self.template_name)

#CreateView
class StudentCreation(View):
    template_name = "studentcreate.html"

    def get(self,request):
        student_form = StudentForm()
        context = {
            'form':student_form
        }
        return render(request, self.template_name, context)

    def post(self,request):
        print(request.POST)
        stud_name = request.POST.get('name')
        stud_age = request.POST.get('age')
        stud_dob = request.POST.get('dob')
        stud_obj = Student.objects.create(name=stud_name,age=stud_age,dob=stud_dob)
        return render(request,self.template_name)

#ListView
class StudentList(View):
    template_name = "studentlist.html"

    def get(self,request):
        students = Student.objects.filter(status=1)
        context = {
            'object_list':students,
        }
        return render(request, self.template_name,context)

#UpdateView
class StudentUpdate(View):
    template_name = "studentupdate.html"

    def get(self,request,pk):
        stud_obj = Student.objects.get(id=pk)
        student_form = StudentForm(
                        initial={
                        'name':stud_obj.name,
                        'age':stud_obj.age,
                        'dob':stud_obj.dob,
                        }
        )
        context = {
            'form':student_form,
        }
        return render(request,self.template_name,context)

    def post(self,request,pk):
        print(request.POST)
        stud_obj = Student.objects.get(id=pk)
        stud_obj.name = request.POST.get('name')
        stud_obj.age = request.POST.get('age')
        stud_obj.dob = request.POST.get('dob')
        stud_obj.save()
        return redirect('studentlist')
