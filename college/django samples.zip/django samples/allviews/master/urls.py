from django.conf.urls import url

from .views import *

urlpatterns = [
    url(r'home',HomeView.as_view(),name="home"),
    url(r'student/create',StudentCreation.as_view(),name="studentcreation"),
    url(r'student/list',StudentList.as_view(),name="studentlist"),
    url(r'student/update/(?P<pk>[0-9]+)',StudentUpdate.as_view(),name="studentupdating"),
]
