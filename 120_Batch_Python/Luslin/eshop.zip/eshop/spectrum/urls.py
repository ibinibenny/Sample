from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from spectrum.views import CreateFeedbackView,ListFeedbackView,CreateDescription,FeedbackDetailView,ListCategoryView,CategoryDetailView,CreateBookCategoryView,ListBookCategoryView,BookCategoryDetailView,CategoryUpdateView,DeleteBookCategoryView,AddBookView

urlpatterns = [
    path(r'feedback/',CreateFeedbackView.as_view(),name='new_fdbk'),
    path(r'listfeedback/',ListFeedbackView.as_view(),name='list_fdbk'),
    path(r'category/',CreateDescription.as_view(),name='new_ctgry'),
    path(r'fdbckdetails/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(),name='fdbk_detail'),
    path(r'listcategory/',ListCategoryView.as_view(),name='list_ctgry'),
    path(r'ctgrydetails/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='ctgry_detail'),
    path(r'bookcategory/',CreateBookCategoryView.as_view(),name='new_bookctgry'),
    path(r'listbookcategory/',ListBookCategoryView.as_view(),name='list_bk'),
    path(r'bookcategory/(?P<pk>[0-9]+)/$',BookCategoryDetailView.as_view(),name='bkctgry_detail'),
    path(r'<pk>/update',CategoryUpdateView.as_view(),name='new_update'),
    path(r'deletebook/(?P<pk>[0-9]+)/$',DeleteBookCategoryView.as_view(),name='delete_bk_ctgry'),
    path(r'newbook/',AddBookView.as_view(),name='new_book'),
    

   
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)