from django import forms
from spectrum.models import FeedbackModel,BooksModel
from spectrum.models import CategoryModel,BookCategoryModel,BooksModel

class FeedbackForm(forms.ModelForm):
	class Meta:
		model = FeedbackModel
		fields= ['name','email','contact','message','place']

class CategoryForm(forms.ModelForm):
	class Meta:
		model= CategoryModel
		fields=['title','description']

class BookCategoryForm(forms.ModelForm):
	class Meta:
			model=BookCategoryModel
			#fields=['title','description','cat_code']
			exclude=['status','created_on']

class BookForm(forms.ModelForm):
	class Meta:
		model = BooksModel
		exclude = ('created_on',)