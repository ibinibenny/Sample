from django.db import models

# Create your models here.

class FeedbackModel(models.Model):
	name= models.CharField(max_length=25)
	email=models.EmailField()
	contact=models.CharField(max_length=30)
	message=models.TextField(max_length=100)
	place=models.CharField(max_length=30)

	def __str__(self):
		return self.name

class CategoryModel(models.Model):
	title=models.CharField(max_length=30)
	description=models.TextField(max_length=300)

	def __str__(self):
		return self.title

class BookCategoryModel(models.Model):
	title=models.CharField(max_length=30)
	cat_code=models.IntegerField(default=1010)
	description=models.TextField(max_length=400)
	status=models.BooleanField(default=True)
	created_on=models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.title

class BooksModel(models.Model):
	bk_catgry = models.ForeignKey(BookCategoryModel,on_delete=models.CASCADE)
	title = models.CharField(max_length=30)
	description = models.TextField(max_length=300)
	author = models.CharField(max_length=30)
	price = models.IntegerField()
	publisher = models.CharField(max_length=30)
	pub_date = models.DateField()
	cover_img = models.ImageField(upload_to='media/')
	pub_agrmnt = models.FileField(upload_to='media/')
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.title

