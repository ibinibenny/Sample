from django.shortcuts import render,redirect

# Create your views here.
from django.views.generic import CreateView,ListView,DetailView,CreateView,ListView,DetailView,View,UpdateView
from spectrum.models import FeedbackModel,BookCategoryModel
from spectrum.forms import FeedbackForm,BookCategoryForm
from spectrum.models import CategoryModel
from spectrum.forms import CategoryForm
from spectrum.models import BooksModel
from spectrum.forms import BookForm


class CreateFeedbackView(CreateView):
	template_name='createfeedback.html'
	model=FeedbackModel
	form_class=FeedbackForm
	success_url= '/general/home/'

class ListFeedbackView(ListView):
	template_name='listfeedback.html'
	model=FeedbackModel
	context_object_name= 'feedbacks'

class CreateDescription(CreateView):
	template_name='createdescription.html'
	model=CategoryModel
	form_class=CategoryForm
	success_url= '/general/home/'

class FeedbackDetailView(DetailView):
	template_name= 'feedback_details.html'
	model= FeedbackModel

class ListCategoryView(ListView):
	template_name='listcategory.html'
	model=CategoryModel
	context_object_name= 'category'

class CategoryDetailView(DetailView):
	template_name='category_details.html'
	model=CategoryModel

class CreateBookCategoryView(View):
	template_name='bookcategory.html'
	form_class= BookCategoryForm

	def get(self,request):
		form=self.form_class()
		context={
		'cat_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form=self.form_class(request.POST)
		if form.is_valid():
			book_cat=BookCategoryModel.objects.create(
				title=request.POST.get('title'),
				description=request.POST.get('description'),
				cat_code=request.POST.get('cat_code')	
				)
			return redirect('/general/home/')
		else:
			form=self.form_class()
			return render(request,self.template_name,{'form':form})

class ListBookCategoryView(View):
	template_name='listbookcategory.html'
	def get(self,request):
		bk_ctgry=BookCategoryModel.objects.all()
		context={
		'ctgry':bk_ctgry
		}
		return render(request,self.template_name,context)

class BookCategoryDetailView(View):
	template_name='bookcategorydetail.html'

	def get(self,request,pk):
		obj = BookCategoryModel.objects.get(id=pk)
		context={
		'catgry':obj
		}
		return render(request,self.template_name,context)

class CategoryUpdateView(UpdateView):
	model=CategoryModel
	fields=['title','description']
	template_name='updateview.html'
	success_url= '/general/home/'

class DeleteBookCategoryView(View):
	template_name='listbookcategory.html'
	def get(self,request,pk):
		cat_obj= BookCategoryModel.objects.get(id=pk).delete()
		bk_ctgry=BookCategoryModel.objects.all()
		context={
		'ctgry':bk_ctgry
		}
		return render(request,self.template_name,context)



class AddBookView(View):
	template_name = 'add_books.html'
	form_class = BookForm

	def get(self,request):
		form = self.form_class()
		context = {
		'book_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			cat_obj = BookCategoryModel.objects.get(id=request.POST.get('bk_catgry'))
			bk_obj = BooksModel.objects.create(
				bk_catgry = cat_obj,
				title = request.POST.get('title'),
				description = request.POST.get('description'),
				author = request.POST.get('author'),
				price = request.POST.get('price'),
				publisher = request.POST.get('publisher'),
				pub_date= request.POST.get('pub_date'),
				cover_img = request.FILES.get('cover_img'),
				pub_agrmnt = request.FILES.get('pub_agrmnt')
				)
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})

class ListBookView(View):
	template_name='listbook.html'

	def get(self,request):
		books=BooksModel.objects.all()
		context={
		'books':books
		}
		return render(request,self.template_name,context)



