from django.contrib import admin

# Register your models here.

from spectrum.models import FeedbackModel
from spectrum.models import CategoryModel
from spectrum.models import BookCategoryModel
from spectrum.models import BooksModel


admin.site.register(FeedbackModel)
admin.site.register(CategoryModel)
admin.site.register(BookCategoryModel)
admin.site.register(BooksModel)
