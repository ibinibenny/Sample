from django.shortcuts import render

from django.contrib.auth.models import User
from customer.models import CustomerModel

from customer.forms import UserForm,CustomerForm
from django.views.generic import FormView
# Create your views here.

class CustomerRegister(FormView):
	template_name='customer_register.html'
	form_class= UserForm


	def get(self,request,*args,**kwargs):
		self.object=None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		cust_form = CustomerForm()
		return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form))
