from django.shortcuts import render

from django.http import HttpResponse
from django.views.generic import TemplateView,View

# Create your views here.

class SamplePageView(TemplateView):
	template_name= 'sample.html'

class HomePageView(TemplateView):
	template_name= 'index1.html'

class ContactView(TemplateView):
	template_name= 'contact1.html'



class AboutView(TemplateView):
	template_name= 'about.html'



class ContactSubmitView(View):
	def get(self,request):
		obj=ContactModel.objects.all()

	def post(self,request):
        
        obj.name=request.POST['name']
        obj.email=request.POST['email']
        obj.message=request.POST['message']
        obj.save()
        return HttpResponse("<h1>Thanks for Contact</h1>")
    
   # return render(request,self.template_name)



