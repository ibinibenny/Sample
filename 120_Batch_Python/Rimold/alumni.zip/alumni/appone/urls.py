from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from appone.views import SamplePageView,HomePageView,ContactView,ContactSubmitView,AboutView


urlpatterns = [
    path('sample1/',SamplePageView.as_view(),name='sample'),
    path('home1/',HomePageView.as_view(),name='home1'),
    path('contact1/',ContactView.as_view(),name='contact1'),
    path('contactsubmit/',ContactSubmitView.as_view(),name='contactsubmit'),
    path('about/',AboutView.as_view(),name='about'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
