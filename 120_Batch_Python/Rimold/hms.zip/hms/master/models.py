from django.db import models

# Create your models here.


class DepartmentModel(models.Model):
	title = models.CharField(max_length=50)
	hod = models.CharField(max_length=50)
	emai=models.EmailField()
	contact=models.IntegerField()
	status=models.BooleanField(default=True)
	description = models.TextField()
	created_on =models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.title