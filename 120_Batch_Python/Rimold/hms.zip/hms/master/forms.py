from django import forms


from master.models import DepartmentModel




class DepartmentForm(forms.ModelForm):
	class Meta:
		model = DepartmentModel
		fields = ['title','hod','emai','contact','description']