from django.shortcuts import redirect, render

from django.views.generic import DetailView,View

from master.models import DepartmentModel
from master.forms import DepartmentForm
# Create your views here.







class CreateDepartmentView(View):
	template_name= 'create_department.html'
	form_class= DepartmentForm
	
	
	def get(self,request):
		form=self.form_class()
		mydict={
			'a':form
		}
		return render(request,self.template_name,mydict)

	def post(self,request):
		form=self.form_class(request.POST)
		if form.is_valid():
			depat=DepartmentModel.objects.create(
				title=request.POST.get('title'),
				hod=request.POST.get('hod'),
				emai=request.POST.get('emai'),
				contact=request.POST.get('contact'),
				description=request.POST.get('description'),
				
			)
			return redirect('/mas/department/')
		else:
			form=self.form_class()
			return render(request,self.template_name,{'form':form})


class ListDepartmentView(View):
	template_name = 'list_department.html'
	# model = DepartmentModel
	# context_object_name= 'feed'

	def get(self,request):
		dpt=DepartmentModel.objects.all()
		mydict={
			'list':dpt
		}
		return render(request,self.template_name,mydict)


class DepartmentDetailView(View):
	template_name = 'department_details.html'
	def get(self,request,pk):
		obj = DepartmentModel.objects.get(id=pk)
		mydictionary={
			'cat': obj
		}
		return render(request,self.template_name,mydictionary)	

class DeleteDepartmentView(View):
	template_name = 'list1_department.html'

	def get(self,request,pk):
		cat_obj = DepartmentModel.objects.get(id=pk).delete()
		book = DepartmentModel.objects.all()
		mydictionary={
			'cat': book
		}
		return render(request,self.template_name,mydictionary)
