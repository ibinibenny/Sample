from django.urls import path


from general.views import HomePageView,AboutPageView


urlpatterns = [
    path('home/',HomePageView.as_view(),name='index_page'),
    path('about/',AboutPageView.as_view(),name='about_us_page'),
]