from django.contrib import admin

# Register your models here.
from general.models import CategoryModel
from general.models import ContactModel,RoomCategoryModel

admin.site.register(ContactModel)
admin.site.register(CategoryModel)
admin.site.register(RoomCategoryModel)
