from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,UpdateView
from general.models import ContactModel,CategoryModel,RoomCategoryModel
from general.forms import ContactForm,CategoryForm,RoomForm

# Create your views here.
class HomePageView(TemplateView):
	template_name = 'index.html'

class AboutPageView(TemplateView):
	template_name = 'about_us.html'

class ContactPageView(View):
	template_name = 'contact_us.html'
	model = ContactModel
	form_class = ContactForm
	
	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)
	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactModel.objects.create(
				name = request.POST.get('name'),
				place = request.POST.get('place'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)

			return redirect('/general/list/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})				
	
class AdminPageView(TemplateView):
	template_name = 'admin.html'


class CategoryView(View):
	template_name = 'addcategory.html'
	form_class = CategoryForm

	def get(self,request):
		form = self.form_class()
		context = {
		'cat_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			bk_obj = CategoryModel.objects.create(
				category = request.POST.get('category'),
				)
			return redirect('/general/listcategory/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})



class CategoryListView(View):
	template_name = 'categorylist.html'
	def get(self,request):
		form = CategoryModel.objects.all()
		context={
		'room':form
		}
		return render(request,self.template_name,context)




class CategoryDetailView(View):
	template_name = 'categorydetails.html'

	def get(self,request,pk):
		obj = CategoryModel.objects.get(id=pk)
		context={
		'room':obj
		}	
		return render(request,self.template_name,context)	

class CategoryDeleteView(View):
	template_name = 'categorylist.html'

	def get(self,request,pk):
		cat_obj = CategoryModel.objects.get(id=pk).delete()
		cat = CategoryModel.objects.all()
		context={
		'room':cat
		}
		return render(request,self.template_name,context)









class RoomPageView(View):
	template_name ='addroom.html'
	form_class = RoomForm

	def get(self,request):
		form = self.form_class()
		context ={
		'room_form':form
		}
		return render(request,self.template_name,context)
	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			cat_obj = CategoryModel.objects.get(id=request.POST.get('room_category'))
			book_room = RoomCategoryModel.objects.create(
				room_name =request.POST.get('room_name'),
				room_num = request.POST.get('room_num'),
				description = request.POST.get('description'),
				room_category=cat_obj,
				image = request.FILES.get('image'),
				room_rate = request.POST.get('room_rate'),
				room_type =request.POST.get('room_type'),
				
				)
				
			return redirect('/general/list/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class ListRoomPageView(View):
	template_name = 'tem.html'
	def get(self,request):
		room = RoomCategoryModel.objects.all()
		context={
		'book':room
		}
		return render(request,self.template_name,context)		


class RoomDetailView(View):
	template_name = 'detail.html'

	def get(self,request,pk):
		obj = RoomCategoryModel.objects.get(id=pk)
		context={
		'book':obj
		}	
		return render(request,self.template_name,context)	

class RoomDeleteView(View):
	template_name = 'tem.html'

	def get(self,request,pk):
		cat_obj = RoomCategoryModel.objects.get(id=pk).delete()
		room = RoomCategoryModel.objects.all()
		context={
		'book':room
		}
		return render(request,self.template_name,context)


class CategoryUpdateView(UpdateView):
	template_name= 'update.html'
	model = RoomCategoryModel
	fields = ['room_name','room_num','room_type','room_category','description','image','room_rate']
	success_url= '/general/list'