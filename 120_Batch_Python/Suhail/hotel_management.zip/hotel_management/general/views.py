from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View,UpdateView
from general.models import ContactModel,RoomCategoryModel
from general.forms import ContactForm,RoomForm

# Create your views here.
class HomePageView(TemplateView):
	template_name = 'index.html'

class AboutPageView(TemplateView):
	template_name = 'about_us.html'

class ContactPageView(View):
	template_name = 'contact_us.html'
	model = ContactModel
	form_class = ContactForm
	
	def get(self,request):
		form = self.form_class()
		context = {
		'contact_form':form
		}
		return render(request,self.template_name,context)
	def post(self,request):
		form = self.form_class(request.POST)
		if form.is_valid():
			contact = ContactModel.objects.create(
				name = request.POST.get('name'),
				place = request.POST.get('place'),
				contact = request.POST.get('contact'),
				message = request.POST.get('message')
				)

			return redirect('/general/list/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})				
	
class AdminPageView(TemplateView):
	template_name = 'admin.html'

class RoomPageView(View):
	template_name ='addroom.html'
	form_class = RoomForm

	def get(self,request):
		form = self.form_class()
		context ={
		'room_form':form
		}
		return render(request,self.template_name,context)
	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			book_room = RoomCategoryModel.objects.create(
				room_name =request.POST.get('room_name'),
				room_num = request.POST.get('room_num'),
				description = request.POST.get('description'),
				image = request.FILES.get('image'),
				room_rate = request.POST.get('room_rate'),
				room_type =request.POST.get('room_type')
				)
				
			return redirect('/general/home')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})	

class ListRoomPageView(View):
	template_name = 'tem.html'
	def get(self,request):
		room = RoomCategoryModel.objects.all()
		context={
		'book':room
		}
		return render(request,self.template_name,context)		


class RoomDetailView(View):
	template_name = 'detail.html'

	def get(self,request,pk):
		obj = RoomCategoryModel.objects.get(id=pk)
		context={
		'book':obj
		}	
		return render(request,self.template_name,context)	

class RoomDeleteView(View):
	template_name = 'tem.html'

	def get(self,request,pk):
		cat_obj = RoomCategoryModel.objects.get(id=pk).delete()
		room = RoomCategoryModel.objects.all()
		context={
		'book':room
		}
		return render(request,self.template_name,context)


class CategoryUpdateView(UpdateView):
	template_name= 'update.html'
	model = RoomCategoryModel
	fields = ['room_name','room_num','room_type','description','image','room_rate']
	success_url= '/general/home'