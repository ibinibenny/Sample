from django.db import models

# Create your models here.
class ContactModel(models.Model):
	name = models.CharField(max_length=50)
	place = models.CharField(max_length=50)
	contact = models.CharField(max_length=50)
	message = models.CharField(max_length= 2000)

	def __str__(self):
		return self.name

class CategoryModel(models.Model):
	category = models.CharField(max_length=30)
	status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.category



class RoomCategoryModel(models.Model):
	room_name = models.CharField(max_length=250)
	room_num = models.IntegerField(max_length=250)
	room_type = models.CharField(max_length=250)
	room_category = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
	description = models.TextField(max_length=250)
	image = models.ImageField(upload_to='media/')
	room_rate = models.IntegerField()
	#status = models.BooleanField(default=True)
	created_on = models.DateTimeField(auto_now=True)
	
	def __str__(self):
		return self.room_name