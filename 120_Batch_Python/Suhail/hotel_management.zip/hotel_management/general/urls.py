from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from general.views import HomePageView,AboutPageView,ContactPageView,AdminPageView,RoomPageView,ListRoomPageView,RoomDetailView,RoomDeleteView,CategoryUpdateView,CategoryView,CategoryListView,CategoryDetailView,CategoryDeleteView


urlpatterns = [
    path('home/',HomePageView.as_view(),name='index_page'),
	path('about/',AboutPageView.as_view(),name='ab_page'),
	path('contact/',ContactPageView.as_view(),name='ct_page'),
	path('admin/',AdminPageView.as_view(),name='admin'),
	
	path(r'category/',CategoryView.as_view(),name='room_category'),
	path(r'listcategory/',CategoryListView.as_view(),name='list_category'),
	path(r'detailcategory/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='category_details'),
	path(r'deletecategory/(?P<pk>[0-9]+)/$',CategoryDeleteView.as_view(),name='delete_category'),

	path('add/',RoomPageView.as_view(),name='add'),
	path('list/',ListRoomPageView.as_view(),name='list'),
	path(r'dal/(?P<pk>[0-9]+)/$',RoomDetailView.as_view(),name='detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',RoomDeleteView.as_view(),name='delete'),
	path('<pk>/update',CategoryUpdateView.as_view(),name='update')
	
	
	
	
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
