from django import forms

from general.models import ContactModel,CategoryModel,RoomCategoryModel

class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','place','contact','message']

class CategoryForm(forms.ModelForm):
	class Meta:
		model = CategoryModel
		exclude = ('status','created_on')


class RoomForm(forms.ModelForm):
	class Meta:
		model = RoomCategoryModel
		exclude =('created_on' ,)
