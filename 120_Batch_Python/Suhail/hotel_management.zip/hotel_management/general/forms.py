from django import forms

from general.models import ContactModel,RoomCategoryModel

class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		fields = ['name','place','contact','message']
class RoomForm(forms.ModelForm):
	class Meta:
		model = RoomCategoryModel
		exclude =('created_on' ,)
