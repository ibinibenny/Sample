from django.contrib import admin
from django.urls import path

from general.views import HomePageView,AboutUsView,ContactUsView

urlpatterns = [
    path('home/', HomePageView.as_view(),name='index_page'),
    path('about/', AboutUsView.as_view(),name='abt_page'),
    path('contact/', ContactUsView.as_view(),name='cntct_page'),

]
