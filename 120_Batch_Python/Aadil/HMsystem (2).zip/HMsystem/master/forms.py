from django import forms

from master.models import DepartmentModel

class DepartmentForm(forms.ModelForm):
	class Meta:
		model = DepartmentModel
		# fields = ['title','contact','email','hod','status','description','created_on']
		exclude=('status','created_on')