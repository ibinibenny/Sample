from django.shortcuts import render,redirect

# Create your views here.
from django.views.generic import View
from master.models import DepartmentModel

from master.forms import DepartmentForm


class CreateDepartmentView(View):
    template_name = 'create_department.html'
    form_class =DepartmentForm
    
    def get(self,request):
        form = self.form_class()
        context ={
        'contact_form':form
        }
        return render(request,self.template_name,context)

    def post(self,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            book_cat = DepartmentModel.objects.create(
                title = request.POST.get('title'),
                description = request.POST.get('description'),
                contact = request.POST.get('contact'),
                email = request.POST.get('email'),
                hod = request.POST.get('hod'),
                
                )
            return redirect('/gen/home/')
        else:
            form = self.form_class()
            return render(request,self.template_name,{'form':form})


class ListDepartmentView(View):
    template_name = 'list_department.html'
    def get(self,request):
       list_dpt= DepartmentModel.objects.all()
       context={
       'dpt' :list_dpt
       }
       return render(request,self.template_name,context)

class DepartmentDetailView(View):
    template_name = 'department_details.html'
    
    def get(self,request,pk):
        obj = DepartmentModel.objects.get(id=pk)
        context = {
        'dpt' :obj
        }
        return render(request,self.template_name,context)


class DeleteDepartmentView(View):
    template_name = 'list_department.html'


    def get (self,request,pk):
        list_dpt = DepartmentModel.objects.get(id=pk).delete()
        
        book = DepartmentModel.objects.all()
        context={
              'dpt':list_dpt
         }
        return render (request,self.template_name,
        context)