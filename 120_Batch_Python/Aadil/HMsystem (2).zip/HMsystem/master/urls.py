from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from master.views import CreateDepartmentView,ListDepartmentView,DepartmentDetailView,DeleteDepartmentView

urlpatterns = [
    path('department/',CreateDepartmentView.as_view(),name='create_dpt'),
    path('listdepartment/',ListDepartmentView.as_view(),name='list_dpt'),
    path(r'departmentdetail/(?P<pk>[0-9]+)/$',DepartmentDetailView.as_view(),name='dept_detail'),
    path(r'delete/(?P<pk>[0-9]+)/$',DeleteDepartmentView.as_view(),name='delete_department'),

]