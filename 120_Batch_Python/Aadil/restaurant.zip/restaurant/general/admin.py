from django.contrib import admin

# Register your models here.
from general.models import ContactModel

admin.site.register(ContactModel)
