from django.contrib import admin

from master.models import FeedbackModel,CategoryModel,BookCategoryModel,BooksModel
# Register your models here.

admin.site.register(FeedbackModel)
admin.site.register(CategoryModel)
admin.site.register(BookCategoryModel)
admin.site.register(BooksModel)
