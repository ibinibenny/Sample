from django.contrib import admin

# Register your models here.
from customer.models import CustomerModel

admin.site.register(CustomerModel)

