from django.shortcuts import render,redirect

from django.views.generic import CreateView,ListView,DetailView,View,UpdateView
from master.models import FeedbackModel,BookCategoryModel
from master.forms import FeedbackForm,BookCategoryForm

from master.models import CategoryModel
from master.forms import CategoryForm


# Create your views here.
class CreateFeedbackView(CreateView):
    template_name = 'create_feedback.html'
    model =FeedbackModel
    form_class = FeedbackForm
    success_url= '/gen/home/'

class ListFeedbackView(ListView):
    template_name = 'list_feedback.html'
    model = FeedbackModel
    context_object_name = 'feedbacks'

class FeedbackDetailView(DetailView):
     template_name = 'feedback_detail.html'
     model = FeedbackModel   


class CategoryView(CreateView):
    template_name= 'category.html'
    model= CategoryModel
    form_class= CategoryForm
    success_url= '/gen/home'

class ListCategoryView(ListView):
    template_name = 'list_category.html'
    model = CategoryModel

class CategoryDetailView(DetailView):
    template_name = 'category_details.html'
    model = CategoryModel


class CategoryUpdateView(UpdateView):
    template_name = 'update.html'
    model = CategoryModel
    fields = ['title','description']
    # form_class = CategoryForm
    success_url= '/gen/home'   


class NewBookCategoryView(View):
    template_name = 'newbk_category.html'
    form_class = BookCategoryForm

    def get(self,request):
        form = self.form_class()
        context ={
        'cat_form':form
        }
        return render(request,self.template_name,context)

    def post(self,request):
        form = self.form_class(request.POST)
        if form.is_valid():
            book_cat = BookCategoryModel.objects.create(
                title = request.POST.get('title'),
                description = request.POST.get('description'),
                cat_code = request.POST.get('cat_code')
                )
            return redirect('/gen/home/')
        else:
            form = self.form_class()
            return render(request,self.template_name,{'form':form})   


class ListBookCategoryView(View):
    template_name = 'list_bk_category.html'
    def get(self,request):
        bk_catgry = BookCategoryModel.objects.all()
        context={
        'catgry':bk_catgry
        }
        return render(request,self.template_name,context)


class BookCategoryDetailView(View):
    template_name = 'bk_catgry_detail.html'

    def get(self,request,pk):
        obj = BookCategoryModel.objects.get(id=pk)
        context={
        'catgry':obj
        }
        return render(request,self.template_name,context)


class DeleteBookCategoryView(View):
    template_name = 'list_bk_category.html'

    def get(self,request,pk):
        cat_obj = BookCategoryModel.objects.get(id=pk).delete()
        bk_catgry = BookCategoryModel.objects.all()
        context={
        'catgry':bk_catgry
        }
        return render(request,self.template_name,context)


