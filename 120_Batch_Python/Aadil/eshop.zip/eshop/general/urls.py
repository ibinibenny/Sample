from django.contrib import admin
from django.urls import path

from general.views import HomePageView,AboutUsView

urlpatterns = [
    path('home/',HomePageView.as_view(),name='index_page'),
    path('about/',AboutUsView.as_view(),name='abt_page')
]
