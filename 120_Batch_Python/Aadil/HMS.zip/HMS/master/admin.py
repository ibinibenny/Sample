from django.contrib import admin

from master.models import DepartmentModel

admin.site.register(DepartmentModel)