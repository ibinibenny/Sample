from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings


from master.views import CreateDepartmentView,ListDepartmentView,DepartmentDeailView,DeleteDepartmentView


urlpatterns = [
	path(r'department/',CreateDepartmentView.as_view(),name='new_depatment'),
	path(r'listdepartment/',ListDepartmentView.as_view(),name='list_department'),
	path(r'departmentdetail/(?P<pk>[0-9]+)/$',DepartmentDeailView.as_view(),name='department_detail'),
	path(r'delete/(?P<pk>[0-9]+)/$',DeleteDepartmentView.as_view(),name='dlt_department'),



]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)