from django import forms

from master.models import DepartmentModel

class DepartmentForm(forms.ModelForm):
	class Meta:
		model = DepartmentModel
		#fields=['title','description','hod','email','contact','status','created_on']
		exclude=('status','created_on')