from django import forms

from master.models import FeedbackModel

class FeedbackForm(forms.ModelForm):
	class Meta:
		model = FeedbackModel
		fields = ['name','email','contact','message','place']