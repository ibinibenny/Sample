from django.contrib import admin

from master.models import FeedbackModel
# Register your models here.


admin.site.register(FeedbackModel)