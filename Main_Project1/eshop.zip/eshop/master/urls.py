from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings


from master.views import CreateFeedbackView,ListFeedbackView,CategoryView,ListCategoryView,FeedbackDetailView,CategoryDetailView,BookCategoryView,CategoryUpdateView,ListBookCategoryView,BookCategoryDetailView




urlpatterns = [
	path('feedback/',CreateFeedbackView.as_view(),name='new_feedback'),
	path('listfeedback/',ListFeedbackView.as_view(),name='new_listfeedback'),
	path('category/',CategoryView.as_view(),name='category'),
	path('listcategory/',ListCategoryView.as_view(),name='listcategory'),
	path('feedbackdetail/(?P<pk>[0-9]+)/$',FeedbackDetailView.as_view(),name='FeedbackD'),
	path('categorydetail/(?P<pk>[0-9]+)/$',CategoryDetailView.as_view(),name='CategoryD'),
	path('bookcategory',BookCategoryView.as_view(),name='bookcategory'),
	path('<pk>/update',CategoryUpdateView.as_view(),name='update'),
	path('listbook/',ListBookCategoryView.as_view(),name='ListBookCategory'),
	path('bookdetail/(?P<pk>[0-9]+)/$',BookCategoryDetailView.as_view(),name='BookCategoryD'),
	
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



