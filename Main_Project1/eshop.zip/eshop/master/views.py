from django.shortcuts import render


from django.views.generic import CreateView
from master.models import FeedbackModel
from master.forms import FeedbackForm
# Create your views here.

class CreateFeedbackView(CreateView):
	template_name= 'create_feedback.html'
	model= FeedbackModel
	form_class= FeedbackForm
	success_url= '/gen/home'