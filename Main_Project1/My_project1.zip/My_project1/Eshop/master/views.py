from django.shortcuts import render

# Create your views here.

from django.views.generic import CreateView

from master.models import FeedbackModel
from master.forms import FeedbackForm



class CreateFeedbackView(CreateView):
	template_name='feedback.html'
	model=FeedbackModel
	form_class=FeedbackForm
	success_url='/general/home/'
		
