from django.shortcuts import render

from django.views.generic import CreateView,ListView,DetailView,View

from master.models import DepartmentModel
from master.forms import DepartmentForm
# Create your views here.







class CreateDepartmentView(CreateView):
	template_name= 'create_department.html'
	model= DepartmentModel
	form_class= DepartmentForm
	success_url= '/gen/home'

class ListDepartmentView(ListView):
	template_name = 'list_department.html'
	model = DepartmentModel
	context_object_name= 'feed'


class DepartmentDetailView(DetailView):
	template_name = 'department_details.html'
	model = DepartmentModel

class DeleteDepartmentView(View):
	template_name = 'list1_department.html'

	def get(self,request,pk):
		cat_obj = DepartmentModel.objects.get(id=pk).delete()
		book = DepartmentModel.objects.all()
		mydictionary={
			'cat': book
		}
		return render(request,self.template_name,mydictionary)
