from django.contrib import admin

from master.models import DepartmentModel
# Register your models here.



admin.site.register(DepartmentModel)