from django import forms


from master.models import DepartmentModel




class DepartmentForm(forms.ModelForm):
	class Meta:
		model = DepartmentModel
		fields = ['first_name','last_name','salary']