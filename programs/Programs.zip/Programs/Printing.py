Name=raw_input('Enter a name :')
print(Name)
Number=raw_input('Enter a number :')
print(Number)
