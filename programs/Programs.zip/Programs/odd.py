num=int(input('Enter a number= '))
def odd():
	if num==0:
		print('Given number is ZERO')
	elif num%2==0:
		print('Given number is EVEN')
	else:
		print('Given number is ODD')
	return num
c=odd()



