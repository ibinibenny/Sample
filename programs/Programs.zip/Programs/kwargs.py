def myFun(**kwargs):  
        d={}
        for key,value in kwargs.items(): 
                d[key]=value
        print(d)
myFun(first ='God', mid ='help', last='us')  
