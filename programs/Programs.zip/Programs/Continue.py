for i in range(1,7):
	if i==5:
		continue
	print(i)


