a=int(input("Enter 1st no:"))
b=int(input("Enter 2nd no:"))
def add():
	c=a+b
	return c
s=add()
print(s)
