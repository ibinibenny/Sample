info= {  'name' : 'meega', 
         'age' : '25', 
         'gender' : 'F'   }       
print('List Of given information: \n') 
for key,value in info.items(): 
    print(key, ":", info[key]) 
