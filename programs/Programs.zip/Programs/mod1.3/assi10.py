x=0
lm1=int(input('Enter 1st number= '))
lm2=int(input('Enter 2nd number= '))
list=[x for x in range(lm1,lm2) if x%2==0]
print('Even numbers between',lm1,'and',lm2,'=',list)
