s1=int(input('Enter 1st data '))
s2=int(input('Enter 2nd data '))
s3=int(input('Enter 3rd data '))
s4=int(input('Enter 4th data '))
s5=int(input('Enter 5th data '))
s6=int(input('Enter 6th data '))

dict1={'num1':s1,'num2':s2,'num3':s3}
dict2={'num4':s4,'num5':s5,'num6':s6}
dict1.update(dict2)
print(dict1)
