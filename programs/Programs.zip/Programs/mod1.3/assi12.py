List = []
Number = int(input("enter the total number of list elements: "))
for i in range(1, Number + 1):
    value = int(input("enter %d number : " %i))
    List.append(value)
print("The smallest element : ", min(List))
print("The largest element : ", max(List))
