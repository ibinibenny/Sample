lm=int(input('Enter the number '))
dict1=dict()
for i in range(1,lm+1):
	key=i
	value=i*i
	dict1[key]=value
print(dict1)
