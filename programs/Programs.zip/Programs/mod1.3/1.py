new_dict_comp = {n:n**2 for n in range(1,50) if n%2 == 0}

print(new_dict_comp)
