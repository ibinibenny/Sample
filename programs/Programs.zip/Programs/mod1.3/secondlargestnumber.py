List = []
Number = int(input("enter the total number of list elements: "))
for i in range(1, Number + 1):
    value = int(input("enter %d number : " %i))
    List.append(value)
List.sort()
print("second largest number is : ", List[Number-2])


list=[]
x=0
s=int(input('Enter the no. of words '))
print('Enter the details')
while x<s:
	name=input('\t')
	list=list+[name.upper()]
	x=x+1
print(list)
