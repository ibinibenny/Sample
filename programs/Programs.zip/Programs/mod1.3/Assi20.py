d={'first':32,'second':84,'third':35,'fourth':345}
print(sum(d.values()))
