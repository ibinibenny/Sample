from functools import reduce
list1=[8,19,6,17]
hex=[reduce(lambda x,y:x+y,list1)]
print(hex)
