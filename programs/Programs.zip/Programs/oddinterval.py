n1=1
n2=50
sum1=0
for i in range(n1,n2+1):
	if(i%2!=0):
		print(i)
		sum1=sum1+i
print("The sum is:",sum1)
