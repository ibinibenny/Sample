num=int(input('Enter the value= '))
n1,n2=0,1
if num>=0:
	for i in range(0,num+1):
		print(n1)
		n3=n1+n2		
		n1=n2
		n2=n3 

