num1=1
num2=50
num3=0
for i in range(num1,num2+i):
if i%2!=0:
	print(i)
	n1=i
	n2=n3
	n3=n1+n2
print("The sum is:",n3)
