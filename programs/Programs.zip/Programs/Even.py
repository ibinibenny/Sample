l=2
for i in range(1,6):
	for j in range(1,i+1):
		print(l,end=" ")
		l=l+2
	print('\n')
