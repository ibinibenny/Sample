l=int(input("Enter length "))
w=int(input("Enter width "))
a=l*w
p=2*(l+w)
print("Area is",a)
print("Perimeter is",p)
