num=int(input("Enter year"))
if(num%4==0):
	if(num%100==0):
		if(num%400==0):
			print("Leap year")
	else:
		print("not")
else:
	print("Not a leap year")
