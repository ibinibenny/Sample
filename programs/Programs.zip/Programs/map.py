list1=[8,19,6,17]
hex=list(map(lambda x:x<10,list1))
print(hex)
