def vararg(*w):
	for i in [w]:
			print(i)
			
vararg(6,7,8,9)
		
