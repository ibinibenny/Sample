list=['Pelican','Gannet','Skew','Albatross']

list[3]='Penguin'
