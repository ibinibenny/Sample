s=int(input("Enter Age"))
if(s>24):
	print("You are not eligible")
elif(s==24):
	print("You are overqualified")
else:
	print("You are qualified")

