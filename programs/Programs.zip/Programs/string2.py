str3="return"
print(str3.replace("r","$"))
