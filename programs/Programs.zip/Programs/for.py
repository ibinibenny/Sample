for i in range(2,50,3):
	print(i)
