num=int(input('Enter a number= '))
if num>0:
	print('Number is Positive')
else:
	print('Number is Negative')
