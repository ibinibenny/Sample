num=int(input("Enter num"))
if(num>0):
	print("Number is positive")
else:
	print("Number is negative")
