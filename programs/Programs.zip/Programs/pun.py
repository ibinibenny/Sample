name=input('Enter the word ')
punc=''',./;'[]\=-<>?:"{}|+_)(*&^%$#@!~`'''
s=''
for char in name:
	if char not in punc:
		s=s+char
print(s)
