sum1=int(input("Enter number"))
n1,n2=0,0
for i in range(1,sum1+1):
	sum1=i
	n1=n2
	sum1=n1+n2
print("Sum is",sum1)
