list1=["Total","Devastation","Poverty"]
for i in enumerate(list1,200):
	print(i)
