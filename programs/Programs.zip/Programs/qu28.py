n1=int(input('Enter 1st number: '))
n2=int(input('Enter 2nd number: '))
if n2%n1==0:
	p=str(n1) +' is a seed of '+ str(n2)
else:
	p=str(n1) +' is not a seed of '+ str(n2)
	
print(p)
