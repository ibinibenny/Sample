num_1 = 10
num_2 = 11
print("division")
print("number is ",num_1)
print("number is ",num_2)
num_1 % num_2
print("substraction")
num_1 - num_2
num_1 * num_2
