def reqarg(name1,id):
	print("id",id)
	print("name",name1)
	return
reqarg(7)
