tup1=(1,2,3)
tup2=(4,5,6)
result=zip(tup1,tup2)
print(tuple(result))
tup1=zip(*result)
print(tup1)

