int=lambda a:a*4
print(int(140))
