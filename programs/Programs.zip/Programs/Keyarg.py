def key(naam,id):
	print("id",id)
	print("name",naam)
	return
key(id=8,naam="tony")
