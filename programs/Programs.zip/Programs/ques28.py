n1=int(input('Enter 1st number: '))
n2=int(input('Enter 2nd number: '))
def seed():
	if n2%n1==0:
		p=str(n1) +' is a seed of '+ str(n2)
	else:
		p=str(n1) +' is not a seed of '+ str(n2)
	return p
a=seed()
print(a)
