name=input('Enter a Name ')
leng=len(name)
slice=name[-6:]
if leng<5:
	new=name+' '+'php'
elif slice=='python':
	new=name+' '+'java'
else:
	new=name+' '+'python'
print(new)                                                    
