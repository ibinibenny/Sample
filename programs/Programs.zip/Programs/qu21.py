num_1=10
num_2=11
num3=num_1 % num_2
print(num3)
num4=num_1 - num_2
print(num4)
num5=num_1 * num_2
print(num5)
