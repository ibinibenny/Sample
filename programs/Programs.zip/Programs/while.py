a=10
while(a>=2):
	a=a-2
	print(a)
