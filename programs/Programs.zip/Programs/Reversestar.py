for i in range(1,7):
	for j in range(1,7-i):
		print('*',end=" ")
	print('\n')
