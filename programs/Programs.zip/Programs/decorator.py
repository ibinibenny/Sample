def addition(func):
	def inner():
		a=60
		b=80
		print(a+b)
		func(a=50,b=50)
	return inner

@addition
def subtraction(a,b):
	c=a-b
	print(c)
subtraction()
