name=input('Enter the word: ')
vowels='A a E e I i O o U u'
s=0
for char in name:
	if char in vowels:
		s=s+1	
print(s)

