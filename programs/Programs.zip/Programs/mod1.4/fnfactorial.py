def fact(n):
	if n==1:
		return 1
	else:
		return n*fact(n-1)
print(fact(5))
num=int(input('Enter the number: '))
fact=1
if num>=0:
	for i in range(1,num+1):
		fact=fact*i
	print(fact)


