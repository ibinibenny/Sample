for i in range(1,8):
	for j in range(1,8-i):
		print('*',end='')
	print('\n')
