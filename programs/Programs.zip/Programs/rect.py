l=12
w=10
P=2*(l+w)
A=l*w
print('Area = ',A)
print('Perimeter = ',P)

