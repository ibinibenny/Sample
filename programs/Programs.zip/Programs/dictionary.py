dict1={'e':7,'u':6,'r':5}
dict
