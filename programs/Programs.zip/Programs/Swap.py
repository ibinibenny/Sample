s1=int(input('Enter first value'))
s2=int(input('Enter second value'))
print("before swapping")
print(s1,s2)
temp=s1
s1=s2
s2=temp
print("after swapping")
print(s1,s2)

