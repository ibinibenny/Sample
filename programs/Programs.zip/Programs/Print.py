Name=input('Enter a name:')
print(Name)
Number=int(input('Enter a number:'))
print(Number)
