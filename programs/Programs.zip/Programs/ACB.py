l=65
for i in range(1,7):
	for j in range(1,i+1):
		print(chr(l),end=" ")
		l=l+1
	print('\n')
