from django.shortcuts import render,redirect


from django.views.generic import CreateView

from master.models import ContactusModel
from master.forms import ContactusForm




# Create your views here.

class CreateContactusView(CreateView):
	template_name= 'create_feedback.html'
	model= ContactusModel
	form_class= ContactusForm
	success_url= '/gen/home'


