from django.contrib import admin

from master.models import ContactusModel
# Register your models here.


admin.site.register(ContactusModel)


