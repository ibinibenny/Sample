from django import forms

from master.models import ContactusModel

class ContactusForm(forms.ModelForm):
	class Meta:
		model = ContactusModel
		fields = ['name','email','contact','message','place']




