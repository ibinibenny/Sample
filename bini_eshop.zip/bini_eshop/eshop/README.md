# eshop
 made when i was studying django at spectrum company
