from django.core.files.base import File
from django.shortcuts import render,redirect
from django.views.generic import View,TemplateView,UpdateView
from general.models import ProductModel
from general.forms import ProductForm 



# Create your views here.

class HomeView(TemplateView):
	template_name = 'home.html'





class AddProductView(View):
	template_name = 'add_product.html'
	form_class = ProductForm

	def get(self,request):
		form = self.form_class()
		context = {
		'product_form':form
		}
		return render(request,self.template_name,context)

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			Product = ProductModel.objects.create(
				name = request.POST.get('name'),
				category = request.POST.get('category'),
				price = request.POST.get('price'),
				description = request.POST.get('description'),
				manufacture_date = request.POST.get('manufacture_date'),
				stock_details = request.POST.get('stock_details'),
				image = request.FILES.get('image')
				

				)
			return redirect('/general/home/')
		else:
			form = self.form_class()
			return render(request,self.template_name,{'form':form})


class  ProductlistView(View):
	template_name = 'product_list.html'
	

	def get(self,request):
		item = ProductModel.objects.all()
		context = {
		'product' :item
		}
		return render(request,self.template_name,context)


class ProductDetailView(View):
	template_name = 'product_detail.html'	

	def get(self,request,pk):
		obj = ProductModel.objects.get(id=pk)
		context = {
		'product' :obj
		}
		return render(request,self.template_name,context)


class DeleteProductView(View):
	template_name = 'product_list.html'

	def get(self,request,pk):
		pro_obj = ProductModel.objects.get(id=pk).delete()
		obj_d = ProductModel.objects.all()
		context = {
		'product' :obj_d
		}
		#return render(request,self.template_name,context)	
		
		return redirect('/general/productlist')


class UpdateProductView(UpdateView):
	template_name = 'update_product.html'
	fields = ['name','category','price','description','stock_details','image']
	model = ProductModel
	success_url = '/general/productlist/'













