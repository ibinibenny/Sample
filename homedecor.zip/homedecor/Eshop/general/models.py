from django.db import models

# Create your models here.


class ProductModel(models.Model):
	name = models.CharField(max_length=50)	
	category = models.CharField(max_length=30)	
	price = models.TextField(max_length=500)
	description = models.TextField(max_length=500)
	
	stock_details = models.IntegerField(null=True,blank=True)
	image = models.ImageField(upload_to='media/')
	status = models.BooleanField(default=True)
	created_on = models.DateField(auto_now=True)

	def __str__(self):
		return self.name
