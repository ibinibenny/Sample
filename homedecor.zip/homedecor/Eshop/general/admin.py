from django.contrib import admin
from general.models import ProductModel
# Register your models here.

admin.site.register(ProductModel)

# Register your models here.
