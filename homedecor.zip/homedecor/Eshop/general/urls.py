from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings 


from general.views import AddProductView,HomeView,ProductlistView,DeleteProductView,ProductDetailView,UpdateProductView
 

urlpatterns = [
    
    path(r'addproduct/',AddProductView.as_view(),name='addproduct_page'),
    path(r'home/',HomeView.as_view(),name='home_page'),
    path(r'productlist/',ProductlistView.as_view(),name='productlist_page'),
    path(r'productdetails/(?P<pk>[0-9]+)/$',ProductDetailView.as_view(),name='product_detail'),
    path(r'delete/(?P<pk>[0-9]+)/$',DeleteProductView.as_view(),name='delete_detail'),
    path(r'<pk>/update/',UpdateProductView.as_view(),name='update_item'),

   

]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
	urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
	urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)